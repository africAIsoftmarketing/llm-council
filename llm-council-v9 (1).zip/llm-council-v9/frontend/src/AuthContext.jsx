import { createContext, useContext, useState, useEffect, useCallback } from 'react';

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [showCreditsModal, setShowCreditsModal] = useState(false);
  const [creditsModalInfo, setCreditsModalInfo] = useState(null);

  const refreshMe = useCallback(async () => {
    try {
      const resp = await fetch('/api/auth/me', { credentials: 'include' });
      if (resp.ok) {
        setUser(await resp.json());
      } else {
        setUser(null);
      }
    } catch {
      setUser(null);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { refreshMe(); }, [refreshMe]);

  const logout = useCallback(async () => {
    await fetch('/api/auth/logout', { method: 'POST', credentials: 'include' });
    setUser(null);
    window.location.href = '/login';
  }, []);

  /** Called by the API layer on HTTP 402 */
  const onInsufficientCredits = useCallback((info) => {
    setCreditsModalInfo(info);
    setShowCreditsModal(true);
  }, []);

  return (
    <AuthContext.Provider value={{
      user, loading, refreshMe, logout,
      showCreditsModal, setShowCreditsModal, creditsModalInfo,
      onInsufficientCredits,
    }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  return useContext(AuthContext);
}

/**
 * Global 402 handler hook — the api layer dispatches a custom event when a
 * request is refused for insufficient credits; this hook opens the modal.
 */
export function useInsufficientCreditsListener() {
  const { onInsufficientCredits } = useAuth();
  useEffect(() => {
    const handler = (e) => onInsufficientCredits(e.detail || {});
    window.addEventListener('llmc:insufficient-credits', handler);
    return () => window.removeEventListener('llmc:insufficient-credits', handler);
  }, [onInsufficientCredits]);
}
