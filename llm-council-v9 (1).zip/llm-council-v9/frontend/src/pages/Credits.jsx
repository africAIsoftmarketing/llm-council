import { useState, useEffect, useCallback } from 'react';
import { PayPalScriptProvider, PayPalButtons } from '@paypal/react-paypal-js';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../AuthContext';
import './Credits.css';

const KIND_LABELS = {
  purchase: 'Achat',
  usage: 'Requête',
  admin_grant: 'Ajustement admin',
  refund: 'Remboursement',
};

function PackCard({ pack, onSuccess, onError }) {
  return (
    <div className="pack-card">
      <div className="pack-name">{pack.name}</div>
      <div className="pack-price">{Number(pack.price_cad).toFixed(2)} $ CAD</div>
      <div className="pack-credits">{pack.credits} crédits</div>
      <PayPalButtons
        style={{ layout: 'horizontal', height: 40, tagline: false }}
        createOrder={async () => {
          const resp = await fetch('/api/payments/orders', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            credentials: 'include',
            body: JSON.stringify({ pack_id: pack.id }),
          });
          if (!resp.ok) throw new Error("Création de l'ordre échouée");
          const data = await resp.json();
          return data.order_id;
        }}
        onApprove={async (data) => {
          const resp = await fetch(`/api/payments/orders/${data.orderID}/capture`, {
            method: 'POST',
            credentials: 'include',
          });
          if (!resp.ok) {
            onError("La capture du paiement a échoué. Si vous avez été débité, les crédits seront ajoutés automatiquement sous peu.");
            return;
          }
          const result = await resp.json();
          onSuccess(pack, result.balance);
        }}
        onError={() => onError('Le paiement PayPal a échoué.')}
      />
    </div>
  );
}

export default function Credits() {
  const { user, refreshMe } = useAuth();
  const navigate = useNavigate();
  const [packsInfo, setPacksInfo] = useState(null);
  const [transactions, setTransactions] = useState([]);
  const [toast, setToast] = useState(null);

  const showToast = (message, type = 'info') => {
    setToast({ message, type });
    setTimeout(() => setToast(null), 5000);
  };

  const loadData = useCallback(async () => {
    try {
      const [packsResp, txResp] = await Promise.all([
        fetch('/api/payments/packs', { credentials: 'include' }),
        fetch('/api/payments/transactions', { credentials: 'include' }),
      ]);
      if (packsResp.ok) setPacksInfo(await packsResp.json());
      if (txResp.ok) setTransactions((await txResp.json()).transactions || []);
    } catch (e) {
      console.error('Failed to load credits data:', e);
    }
  }, []);

  useEffect(() => { loadData(); }, [loadData]);

  const handleSuccess = async (pack, balance) => {
    showToast(`✓ Pack ${pack.name} acheté — nouveau solde : ${balance} crédits`, 'success');
    await refreshMe();
    await loadData();
  };

  if (!packsInfo) {
    return <div className="credits-page"><div className="credits-loading">Chargement…</div></div>;
  }

  return (
    <div className="credits-page">
      <div className="credits-header">
        <button className="back-btn" onClick={() => navigate('/')}>← Retour</button>
        <h1>Acheter des crédits</h1>
        <div className="current-balance">
          Solde actuel : <strong>{user?.credits ?? 0} crédits</strong>
        </div>
      </div>

      <div className="cost-info">
        Coût par requête : {packsInfo.request_cost?.standard ?? 10} crédits
        (avec images : {packsInfo.request_cost?.vision ?? 15} crédits)
      </div>

      {!packsInfo.payments_enabled ? (
        <div className="payments-disabled">
          Les paiements ne sont pas encore configurés sur ce serveur.
          Contactez l'administrateur.
        </div>
      ) : (
        <PayPalScriptProvider options={{
          clientId: packsInfo.paypal_client_id,
          currency: 'CAD',
          intent: 'capture',
        }}>
          <div className="packs-grid">
            {packsInfo.packs.map((pack) => (
              <PackCard
                key={pack.id}
                pack={pack}
                onSuccess={handleSuccess}
                onError={(msg) => showToast(msg, 'error')}
              />
            ))}
          </div>
        </PayPalScriptProvider>
      )}

      <div className="tx-section">
        <h2>Historique des transactions</h2>
        {transactions.length === 0 ? (
          <p className="tx-empty">Aucune transaction pour le moment.</p>
        ) : (
          <table className="tx-table">
            <thead>
              <tr>
                <th>Date</th><th>Type</th><th>Montant</th><th>Solde après</th>
              </tr>
            </thead>
            <tbody>
              {transactions.map((tx) => (
                <tr key={tx.id}>
                  <td>{new Date(tx.created_at).toLocaleString('fr-CA')}</td>
                  <td>{KIND_LABELS[tx.kind] || tx.kind}</td>
                  <td className={tx.amount >= 0 ? 'tx-pos' : 'tx-neg'}>
                    {tx.amount >= 0 ? '+' : ''}{tx.amount}
                  </td>
                  <td>{tx.balance_after}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {toast && <div className={`toast toast-${toast.type}`}>{toast.message}</div>}
    </div>
  );
}
