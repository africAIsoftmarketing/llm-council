import { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../AuthContext';
import './Admin.css';

async function adminFetch(url, options = {}) {
  const resp = await fetch(url, {
    credentials: 'include',
    headers: { 'Content-Type': 'application/json', ...(options.headers || {}) },
    ...options,
  });
  if (!resp.ok) {
    let detail = `Erreur ${resp.status}`;
    try {
      const data = await resp.json();
      detail = typeof data.detail === 'string' ? data.detail : JSON.stringify(data.detail);
    } catch { /* keep default */ }
    throw new Error(detail);
  }
  return resp.json();
}

// ============================ Onglet Modèles ============================

function ModelsTab({ showToast }) {
  const [models, setModels] = useState([]);
  const [chairman, setChairman] = useState('');
  const [newModel, setNewModel] = useState('');
  const [validating, setValidating] = useState(false);

  const load = useCallback(async () => {
    try {
      const data = await adminFetch('/api/admin/models');
      setModels(data.council_models || []);
      setChairman(data.chairman_model || '');
    } catch (e) { showToast(e.message, 'error'); }
  }, [showToast]);

  useEffect(() => { load(); }, [load]);

  const addModel = async () => {
    if (!newModel.trim()) return;
    setValidating(true);
    try {
      await adminFetch('/api/admin/models', {
        method: 'POST',
        body: JSON.stringify({ model_id: newModel.trim() }),
      });
      showToast(`✓ Modèle ${newModel.trim()} validé et ajouté`, 'success');
      setNewModel('');
      await load();
    } catch (e) { showToast(e.message, 'error'); }
    finally { setValidating(false); }
  };

  const removeModel = async (modelId) => {
    if (!window.confirm(`Supprimer ${modelId} du council ?`)) return;
    try {
      await adminFetch(`/api/admin/models/${encodeURIComponent(modelId)}`, { method: 'DELETE' });
      showToast('Modèle supprimé', 'success');
      await load();
    } catch (e) { showToast(e.message, 'error'); }
  };

  const setChairmanModel = async (modelId) => {
    try {
      await adminFetch('/api/admin/chairman', {
        method: 'PUT',
        body: JSON.stringify({ model_id: modelId }),
      });
      setChairman(modelId);
      showToast(`Chairman : ${modelId}`, 'success');
    } catch (e) { showToast(e.message, 'error'); }
  };

  return (
    <div className="admin-tab-content">
      <h3>Modèles du council</h3>
      <ul className="model-list">
        {models.map((m) => (
          <li key={m} className="model-row">
            <span className="model-id">{m}</span>
            {m === chairman && <span className="chairman-badge">Chairman</span>}
            <div className="model-actions">
              {m !== chairman && (
                <button className="mini-btn" onClick={() => setChairmanModel(m)}>
                  Définir chairman
                </button>
              )}
              <button className="mini-btn danger" onClick={() => removeModel(m)}
                      disabled={models.length <= 2}>
                🗑
              </button>
            </div>
          </li>
        ))}
      </ul>
      <div className="add-model-row">
        <input
          type="text"
          placeholder="provider/model (ex. anthropic/claude-sonnet-4-5)"
          value={newModel}
          onChange={(e) => setNewModel(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && addModel()}
        />
        <button className="primary-btn" onClick={addModel} disabled={validating}>
          {validating ? 'Validation OpenRouter…' : 'Ajouter et valider'}
        </button>
      </div>
      <p className="tab-hint">
        Les changements prennent effet en moins de 60 secondes (cache serveur), sans redéploiement.
      </p>
    </div>
  );
}

// ============================ Onglet Utilisateurs ============================

function UsersTab({ showToast, currentUserId }) {
  const [data, setData] = useState({ total: 0, users: [] });
  const [search, setSearch] = useState('');
  const [page, setPage] = useState(0);
  const PAGE_SIZE = 20;

  const load = useCallback(async () => {
    try {
      const params = new URLSearchParams({
        search, limit: PAGE_SIZE, offset: page * PAGE_SIZE,
      });
      setData(await adminFetch(`/api/admin/users?${params}`));
    } catch (e) { showToast(e.message, 'error'); }
  }, [search, page, showToast]);

  useEffect(() => { load(); }, [load]);

  const adjustCredits = async (u) => {
    const raw = window.prompt(
      `Ajustement de crédits pour ${u.email} (solde: ${u.credits}).\n` +
      `Entrez un montant (+ pour créditer, − pour débiter) :`
    );
    if (!raw) return;
    const amount = parseInt(raw, 10);
    if (isNaN(amount) || amount === 0) { showToast('Montant invalide', 'error'); return; }
    const reason = window.prompt('Motif de l\'ajustement :') || '';
    try {
      const result = await adminFetch(`/api/admin/users/${u.id}/credits`, {
        method: 'POST',
        body: JSON.stringify({ amount, reason }),
      });
      showToast(`✓ Nouveau solde de ${u.email} : ${result.balance}`, 'success');
      await load();
    } catch (e) { showToast(e.message, 'error'); }
  };

  const patchUser = async (u, patch, label) => {
    try {
      await adminFetch(`/api/admin/users/${u.id}`, {
        method: 'PATCH',
        body: JSON.stringify(patch),
      });
      showToast(`✓ ${label}`, 'success');
      await load();
    } catch (e) { showToast(e.message, 'error'); }
  };

  return (
    <div className="admin-tab-content">
      <div className="users-toolbar">
        <input
          type="text" placeholder="Rechercher par email…"
          value={search}
          onChange={(e) => { setSearch(e.target.value); setPage(0); }}
        />
        <span className="users-total">{data.total} utilisateur(s)</span>
      </div>
      <table className="admin-table">
        <thead>
          <tr>
            <th>Email</th><th>Nom</th><th>Rôle</th><th>Crédits</th>
            <th>Requêtes</th><th>Dernière connexion</th><th>Statut</th><th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {data.users.map((u) => (
            <tr key={u.id} className={!u.is_active ? 'row-disabled' : ''}>
              <td>{u.email}</td>
              <td>{u.display_name}</td>
              <td>{u.role === 'admin' ? '👑 admin' : 'user'}</td>
              <td>{u.credits}</td>
              <td>{u.request_count}</td>
              <td>{u.last_login_at ? new Date(u.last_login_at).toLocaleDateString('fr-CA') : '—'}</td>
              <td>{u.is_active ? '✓ actif' : '✗ désactivé'}</td>
              <td className="user-actions">
                <button className="mini-btn" onClick={() => adjustCredits(u)}>± Crédits</button>
                {u.id !== currentUserId && (
                  <>
                    <button className="mini-btn"
                            onClick={() => patchUser(u, { is_active: !u.is_active },
                              u.is_active ? 'Compte désactivé' : 'Compte réactivé')}>
                      {u.is_active ? 'Désactiver' : 'Activer'}
                    </button>
                    <button className="mini-btn"
                            onClick={() => patchUser(u,
                              { role: u.role === 'admin' ? 'user' : 'admin' },
                              u.role === 'admin' ? 'Rétrogradé en user' : 'Promu admin')}>
                      {u.role === 'admin' ? 'Rétrograder' : 'Promouvoir'}
                    </button>
                  </>
                )}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      <div className="pagination">
        <button className="mini-btn" disabled={page === 0}
                onClick={() => setPage(page - 1)}>← Précédent</button>
        <span>Page {page + 1} / {Math.max(1, Math.ceil(data.total / PAGE_SIZE))}</span>
        <button className="mini-btn"
                disabled={(page + 1) * PAGE_SIZE >= data.total}
                onClick={() => setPage(page + 1)}>Suivant →</button>
      </div>
    </div>
  );
}

// ============================ Onglet Tarification ============================

function PricingTab({ showToast }) {
  const [packs, setPacks] = useState([]);
  const [cost, setCost] = useState({ standard: 10, vision: 15 });

  const load = useCallback(async () => {
    try {
      const data = await adminFetch('/api/admin/settings');
      setPacks(data.credit_packs || []);
      setCost(data.request_cost || { standard: 10, vision: 15 });
    } catch (e) { showToast(e.message, 'error'); }
  }, [showToast]);

  useEffect(() => { load(); }, [load]);

  const updatePack = (i, field, value) => {
    const next = packs.map((p, idx) => idx === i ? { ...p, [field]: value } : p);
    setPacks(next);
  };

  const savePacks = async () => {
    try {
      const cleaned = packs.map((p) => ({
        id: p.id, name: p.name,
        price_cad: parseFloat(p.price_cad), credits: parseInt(p.credits, 10),
      }));
      await adminFetch('/api/admin/settings/credit_packs', {
        method: 'PUT', body: JSON.stringify({ value: cleaned }),
      });
      showToast('✓ Packs enregistrés', 'success');
    } catch (e) { showToast(e.message, 'error'); }
  };

  const saveCost = async () => {
    try {
      await adminFetch('/api/admin/settings/request_cost', {
        method: 'PUT',
        body: JSON.stringify({ value: {
          standard: parseInt(cost.standard, 10),
          vision: parseInt(cost.vision, 10),
        }}),
      });
      showToast('✓ Coûts par requête enregistrés', 'success');
    } catch (e) { showToast(e.message, 'error'); }
  };

  return (
    <div className="admin-tab-content">
      <h3>Packs de crédits</h3>
      <table className="admin-table">
        <thead><tr><th>ID</th><th>Nom</th><th>Prix (CAD)</th><th>Crédits</th></tr></thead>
        <tbody>
          {packs.map((p, i) => (
            <tr key={p.id}>
              <td>{p.id}</td>
              <td><input value={p.name} onChange={(e) => updatePack(i, 'name', e.target.value)} /></td>
              <td><input type="number" step="0.01" value={p.price_cad}
                         onChange={(e) => updatePack(i, 'price_cad', e.target.value)} /></td>
              <td><input type="number" value={p.credits}
                         onChange={(e) => updatePack(i, 'credits', e.target.value)} /></td>
            </tr>
          ))}
        </tbody>
      </table>
      <button className="primary-btn" onClick={savePacks}>Enregistrer les packs</button>

      <h3 style={{ marginTop: 28 }}>Coût par requête</h3>
      <div className="cost-editor">
        <label>
          Standard :
          <input type="number" value={cost.standard}
                 onChange={(e) => setCost({ ...cost, standard: e.target.value })} />
          crédits
        </label>
        <label>
          Avec images (vision) :
          <input type="number" value={cost.vision}
                 onChange={(e) => setCost({ ...cost, vision: e.target.value })} />
          crédits
        </label>
        <button className="primary-btn" onClick={saveCost}>Enregistrer les coûts</button>
      </div>
    </div>
  );
}

// ============================ Onglet Statistiques ============================

const KIND_LABELS = {
  purchase: 'Achat', usage: 'Requête',
  admin_grant: 'Ajustement admin', refund: 'Remboursement',
};

function StatsTab({ showToast }) {
  const [stats, setStats] = useState(null);

  useEffect(() => {
    adminFetch('/api/admin/stats')
      .then(setStats)
      .catch((e) => showToast(e.message, 'error'));
  }, [showToast]);

  if (!stats) return <div className="admin-tab-content">Chargement…</div>;

  return (
    <div className="admin-tab-content">
      <div className="stats-cards">
        <div className="stat-card">
          <div className="stat-value">{stats.revenue_cad.toFixed(2)} $</div>
          <div className="stat-label">Revenus (CAD)</div>
        </div>
        <div className="stat-card">
          <div className="stat-value">{stats.credits_used}</div>
          <div className="stat-label">Crédits consommés</div>
        </div>
        <div className="stat-card">
          <div className="stat-value">{stats.active_users}</div>
          <div className="stat-label">Utilisateurs actifs</div>
        </div>
        <div className="stat-card">
          <div className="stat-value">{stats.requests_7d} / {stats.requests_30d}</div>
          <div className="stat-label">Requêtes (7 j / 30 j)</div>
        </div>
      </div>
      <h3>50 dernières transactions</h3>
      <table className="admin-table">
        <thead>
          <tr><th>Date</th><th>Utilisateur</th><th>Type</th><th>Montant</th><th>Solde après</th></tr>
        </thead>
        <tbody>
          {(stats.transactions || []).map((tx) => (
            <tr key={tx.id}>
              <td>{new Date(tx.created_at).toLocaleString('fr-CA')}</td>
              <td>{tx.email}</td>
              <td>{KIND_LABELS[tx.kind] || tx.kind}</td>
              <td className={tx.amount >= 0 ? 'tx-pos' : 'tx-neg'}>
                {tx.amount >= 0 ? '+' : ''}{tx.amount}
              </td>
              <td>{tx.balance_after}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

// ============================ Page Admin ============================

const TABS = [
  { id: 'models', label: 'Modèles' },
  { id: 'users', label: 'Utilisateurs' },
  { id: 'pricing', label: 'Tarification' },
  { id: 'stats', label: 'Statistiques' },
];

export default function Admin() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [tab, setTab] = useState('models');
  const [toast, setToast] = useState(null);

  const showToast = useCallback((message, type = 'info') => {
    setToast({ message, type });
    setTimeout(() => setToast(null), 5000);
  }, []);

  if (user && user.role !== 'admin') {
    navigate('/');
    return null;
  }

  return (
    <div className="admin-page">
      <div className="admin-header">
        <button className="back-btn" onClick={() => navigate('/')}>← Retour</button>
        <h1>Administration</h1>
      </div>
      <div className="admin-tabs">
        {TABS.map((t) => (
          <button key={t.id}
                  className={`admin-tab ${tab === t.id ? 'active' : ''}`}
                  onClick={() => setTab(t.id)}>
            {t.label}
          </button>
        ))}
      </div>
      {tab === 'models' && <ModelsTab showToast={showToast} />}
      {tab === 'users' && <UsersTab showToast={showToast} currentUserId={user?.id} />}
      {tab === 'pricing' && <PricingTab showToast={showToast} />}
      {tab === 'stats' && <StatsTab showToast={showToast} />}
      {toast && <div className={`toast toast-${toast.type}`}>{toast.message}</div>}
    </div>
  );
}
