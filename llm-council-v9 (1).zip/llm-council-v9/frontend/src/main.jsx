import { StrictMode, useEffect } from 'react'
import { createRoot } from 'react-dom/client'
import { BrowserRouter, Routes, Route, Navigate, useLocation } from 'react-router-dom'
import './index.css'
import App from './App.jsx'
import Login from './pages/Login.jsx'
import Credits from './pages/Credits.jsx'
import Admin from './pages/Admin.jsx'
import { AuthProvider, useAuth, useInsufficientCreditsListener } from './AuthContext.jsx'
import { TopBar, InsufficientCreditsModal } from './components/TopBar.jsx'

function RequireAuth({ children }) {
  const { user, loading } = useAuth();
  const location = useLocation();
  if (loading) {
    return <div style={{ padding: 60, textAlign: 'center', color: '#666' }}>Chargement…</div>;
  }
  if (!user) {
    return <Navigate to="/login" replace state={{ from: location }} />;
  }
  return children;
}

function AuthedLayout({ children }) {
  useInsufficientCreditsListener();
  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100vh' }}>
      <TopBar />
      <div style={{ flex: 1, overflow: 'hidden' }}>{children}</div>
      <InsufficientCreditsModal />
    </div>
  );
}

function LoginRoute() {
  const { user, loading } = useAuth();
  if (loading) return null;
  if (user) return <Navigate to="/" replace />;
  return <Login />;
}

createRoot(document.getElementById('root')).render(
  <StrictMode>
    <AuthProvider>
      <BrowserRouter>
        <Routes>
          <Route path="/login" element={<LoginRoute />} />
          <Route path="/credits" element={
            <RequireAuth><AuthedLayout><Credits /></AuthedLayout></RequireAuth>
          } />
          <Route path="/admin" element={
            <RequireAuth><AuthedLayout><Admin /></AuthedLayout></RequireAuth>
          } />
          <Route path="/*" element={
            <RequireAuth><AuthedLayout><App /></AuthedLayout></RequireAuth>
          } />
        </Routes>
      </BrowserRouter>
    </AuthProvider>
  </StrictMode>,
)
