"""v9 — Google SSO authentication (authlib) + JWT session cookie.

OPEN mode: when DATABASE_URL or GOOGLE_CLIENT_ID is missing, auth is
disabled and every request runs as a local dev user with admin role and
unlimited credits. This keeps local development working without Google
credentials; production (Heroku with env vars set) enforces full auth.
"""

import os
import time
import logging
from typing import Optional, Dict, Any

import jwt
from fastapi import APIRouter, Request, HTTPException, Depends
from fastapi.responses import RedirectResponse, JSONResponse

logger = logging.getLogger(__name__)

try:
    from . import db
except ImportError:
    import db

GOOGLE_CLIENT_ID = os.getenv("GOOGLE_CLIENT_ID", "")
GOOGLE_CLIENT_SECRET = os.getenv("GOOGLE_CLIENT_SECRET", "")
JWT_SECRET = os.getenv("JWT_SECRET", "")
ADMIN_EMAILS = [e.strip() for e in os.getenv("ADMIN_EMAILS", "").split(",") if e.strip()]
JWT_TTL_SECONDS = 7 * 24 * 3600  # 7 days
COOKIE_NAME = "llmc_session"

AUTH_ENABLED = bool(db.USE_PG and GOOGLE_CLIENT_ID and GOOGLE_CLIENT_SECRET and JWT_SECRET)

router = APIRouter(prefix="/api/auth", tags=["auth"])

# --- OAuth client (lazy — only if enabled) ---
_oauth = None


def _get_oauth():
    global _oauth
    if _oauth is None:
        from authlib.integrations.starlette_client import OAuth
        _oauth = OAuth()
        _oauth.register(
            name="google",
            client_id=GOOGLE_CLIENT_ID,
            client_secret=GOOGLE_CLIENT_SECRET,
            server_metadata_url="https://accounts.google.com/.well-known/openid-configuration",
            client_kwargs={"scope": "openid email profile"},
        )
    return _oauth


# ---------------------------------------------------------------------------
# JWT helpers
# ---------------------------------------------------------------------------

def _issue_jwt(user: Dict[str, Any]) -> str:
    now = int(time.time())
    payload = {
        "sub": user["id"],
        "email": user["email"],
        "role": user["role"],
        "iat": now,
        "exp": now + JWT_TTL_SECONDS,
    }
    return jwt.encode(payload, JWT_SECRET, algorithm="HS256")


def _decode_jwt(token: str) -> Optional[Dict[str, Any]]:
    try:
        return jwt.decode(token, JWT_SECRET, algorithms=["HS256"])
    except jwt.PyJWTError:
        return None


def _set_session_cookie(response, token: str):
    secure = os.getenv("COOKIE_SECURE", "auto")
    is_secure = (secure == "true") or (secure == "auto" and bool(os.getenv("DYNO")))
    response.set_cookie(
        COOKIE_NAME, token,
        max_age=JWT_TTL_SECONDS,
        httponly=True,
        samesite="lax",
        secure=is_secure,
        path="/",
    )


# ---------------------------------------------------------------------------
# Dev user for OPEN mode (no DB / no Google configured)
# ---------------------------------------------------------------------------

_DEV_USER = {
    "id": "00000000-0000-0000-0000-000000000000",
    "email": "dev@localhost",
    "display_name": "Dev (mode ouvert)",
    "avatar_url": None,
    "role": "admin",
    "credits": 999999,
    "is_active": True,
}


# ---------------------------------------------------------------------------
# FastAPI dependencies
# ---------------------------------------------------------------------------

async def get_current_user(request: Request) -> Dict[str, Any]:
    """Resolve the current user from the JWT cookie. 401 if absent/invalid."""
    if not AUTH_ENABLED:
        return dict(_DEV_USER)
    token = request.cookies.get(COOKIE_NAME)
    if not token:
        raise HTTPException(status_code=401, detail="Non authentifié")
    payload = _decode_jwt(token)
    if not payload:
        raise HTTPException(status_code=401, detail="Session invalide ou expirée")
    user = db.get_user(payload["sub"])
    if user is None or not user["is_active"]:
        raise HTTPException(status_code=401, detail="Compte inexistant ou désactivé")
    return user


async def get_current_admin(user: Dict[str, Any] = Depends(get_current_user)) -> Dict[str, Any]:
    if user.get("role") != "admin":
        raise HTTPException(status_code=403, detail="Accès administrateur requis")
    return user


# ---------------------------------------------------------------------------
# Routes
# ---------------------------------------------------------------------------

@router.get("/login")
async def login(request: Request):
    if not AUTH_ENABLED:
        return JSONResponse({"auth_enabled": False, "detail": "Auth désactivée (mode ouvert)"})
    oauth = _get_oauth()
    redirect_uri = str(request.url_for("auth_callback"))
    # Force https behind Heroku's proxy
    if os.getenv("DYNO") and redirect_uri.startswith("http://"):
        redirect_uri = "https://" + redirect_uri[len("http://"):]
    return await oauth.google.authorize_redirect(request, redirect_uri)


@router.get("/callback", name="auth_callback")
async def auth_callback(request: Request):
    if not AUTH_ENABLED:
        return RedirectResponse("/")
    oauth = _get_oauth()
    try:
        token = await oauth.google.authorize_access_token(request)
    except Exception as e:
        logger.error("OAuth callback failed: %s", e)
        return RedirectResponse("/login?error=oauth_failed")
    userinfo = token.get("userinfo") or {}
    google_sub = userinfo.get("sub")
    email = userinfo.get("email")
    if not google_sub or not email:
        return RedirectResponse("/login?error=missing_profile")

    user = db.upsert_user_from_google(
        google_sub=google_sub,
        email=email,
        display_name=userinfo.get("name") or email.split("@")[0],
        avatar_url=userinfo.get("picture"),
        admin_emails=ADMIN_EMAILS,
    )
    if not user["is_active"]:
        return RedirectResponse("/login?error=account_disabled")

    response = RedirectResponse("/")
    _set_session_cookie(response, _issue_jwt(user))
    return response


@router.post("/logout")
async def logout():
    response = JSONResponse({"ok": True})
    response.delete_cookie(COOKIE_NAME, path="/")
    return response


@router.get("/me")
async def me(user: Dict[str, Any] = Depends(get_current_user)):
    return {
        "id": user["id"],
        "email": user["email"],
        "display_name": user.get("display_name"),
        "avatar_url": user.get("avatar_url"),
        "role": user["role"],
        "credits": user["credits"],
        "auth_enabled": AUTH_ENABLED,
    }
