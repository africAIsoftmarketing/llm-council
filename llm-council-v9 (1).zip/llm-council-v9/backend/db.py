"""v9 — Database layer: schema migrations, app settings, credit operations.

Builds on the existing psycopg2 pool in storage.py (storage._pg()).
Active only when DATABASE_URL is set; in local/JSON mode the app runs
in OPEN mode (no auth, no credits) for development.

Tables owned by this module:
  users, credit_transactions, app_settings
Plus: adds user_id column to the existing conversations table.
"""

import os
import time
import json
import uuid
import logging
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)

try:
    from . import storage
    from .config import COUNCIL_MODELS, CHAIRMAN_MODEL
except ImportError:
    import storage
    from config import COUNCIL_MODELS, CHAIRMAN_MODEL

USE_PG = bool(os.getenv("DATABASE_URL"))

# ---------------------------------------------------------------------------
# Default seed values (editable later from the admin panel)
# ---------------------------------------------------------------------------

DEFAULT_SETTINGS: Dict[str, Any] = {
    "council_models": list(COUNCIL_MODELS),
    "chairman_model": CHAIRMAN_MODEL,
    "credit_packs": [
        {"id": "decouverte", "name": "Découverte", "price_cad": 5.0, "credits": 50},
        {"id": "standard", "name": "Standard", "price_cad": 15.0, "credits": 200},
        {"id": "pro", "name": "Pro", "price_cad": 40.0, "credits": 650},
    ],
    "request_cost": {"standard": 10, "vision": 15},
}


# ---------------------------------------------------------------------------
# Migrations (idempotent — safe to run at every startup / release phase)
# ---------------------------------------------------------------------------

MIGRATION_SQL = """
CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TABLE IF NOT EXISTS users (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    google_sub TEXT UNIQUE NOT NULL,
    email TEXT UNIQUE NOT NULL,
    display_name TEXT,
    avatar_url TEXT,
    role TEXT NOT NULL DEFAULT 'user',
    credits INTEGER NOT NULL DEFAULT 0,
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    last_login_at TIMESTAMPTZ
);

CREATE TABLE IF NOT EXISTS credit_transactions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES users(id),
    amount INTEGER NOT NULL,
    kind TEXT NOT NULL,
    paypal_order_id TEXT,
    paypal_capture_id TEXT,
    conversation_id TEXT,
    note TEXT,
    balance_after INTEGER NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE UNIQUE INDEX IF NOT EXISTS uq_credit_tx_paypal_order
    ON credit_transactions (paypal_order_id)
    WHERE paypal_order_id IS NOT NULL;

CREATE INDEX IF NOT EXISTS ix_credit_tx_user_created
    ON credit_transactions (user_id, created_at DESC);

CREATE TABLE IF NOT EXISTS app_settings (
    key TEXT PRIMARY KEY,
    value JSONB NOT NULL,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_by UUID REFERENCES users(id)
);

ALTER TABLE conversations ADD COLUMN IF NOT EXISTS user_id UUID REFERENCES users(id);
CREATE INDEX IF NOT EXISTS ix_conversations_user ON conversations (user_id, created_at DESC);
"""


def run_migrations():
    """Apply the schema and seed default settings. Idempotent."""
    if not USE_PG:
        logger.warning("db: DATABASE_URL not set — running in OPEN mode (no auth/credits).")
        return
    with storage._pg() as conn:
        with conn.cursor() as cur:
            # conversations table might not exist yet on a fresh DB
            cur.execute(
                """
                CREATE TABLE IF NOT EXISTS conversations (
                    id TEXT PRIMARY KEY,
                    data JSONB NOT NULL,
                    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
                    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
                );
                """
            )
            cur.execute(MIGRATION_SQL)
            # Seed default settings if absent
            from psycopg2.extras import Json
            for key, value in DEFAULT_SETTINGS.items():
                cur.execute(
                    """
                    INSERT INTO app_settings (key, value)
                    VALUES (%s, %s)
                    ON CONFLICT (key) DO NOTHING
                    """,
                    (key, Json(value)),
                )
    logger.info("db: migrations applied, defaults seeded.")


# ---------------------------------------------------------------------------
# App settings — cached reads (60 s), server-authoritative values
# ---------------------------------------------------------------------------

_SETTINGS_CACHE: Dict[str, Any] = {}
_SETTINGS_CACHE_AT: float = 0.0
SETTINGS_TTL = 60.0


def _load_all_settings() -> Dict[str, Any]:
    with storage._pg() as conn:
        with conn.cursor() as cur:
            cur.execute("SELECT key, value FROM app_settings")
            return {row[0]: row[1] for row in cur.fetchall()}


def get_setting(key: str, default: Any = None, fresh: bool = False) -> Any:
    """Read a setting with a 60 s memory cache. Falls back to defaults."""
    global _SETTINGS_CACHE, _SETTINGS_CACHE_AT
    if not USE_PG:
        return DEFAULT_SETTINGS.get(key, default)
    now = time.time()
    if fresh or not _SETTINGS_CACHE or (now - _SETTINGS_CACHE_AT) > SETTINGS_TTL:
        try:
            _SETTINGS_CACHE = _load_all_settings()
            _SETTINGS_CACHE_AT = now
        except Exception as e:
            logger.error("db: failed to load settings (%s) — using cache/defaults", e)
    if key in _SETTINGS_CACHE:
        return _SETTINGS_CACHE[key]
    return DEFAULT_SETTINGS.get(key, default)


def set_setting(key: str, value: Any, updated_by: Optional[str] = None) -> Any:
    """Upsert a setting and invalidate the cache."""
    global _SETTINGS_CACHE_AT
    from psycopg2.extras import Json
    with storage._pg() as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                INSERT INTO app_settings (key, value, updated_at, updated_by)
                VALUES (%s, %s, now(), %s)
                ON CONFLICT (key) DO UPDATE
                SET value = EXCLUDED.value, updated_at = now(), updated_by = EXCLUDED.updated_by
                """,
                (key, Json(value), updated_by),
            )
    _SETTINGS_CACHE_AT = 0.0  # force refresh on next read
    return value


# ---------------------------------------------------------------------------
# Users
# ---------------------------------------------------------------------------

_USER_COLS = (
    "id, google_sub, email, display_name, avatar_url, role, credits, "
    "is_active, created_at, last_login_at"
)


def _row_to_user(row) -> Dict[str, Any]:
    return {
        "id": str(row[0]),
        "google_sub": row[1],
        "email": row[2],
        "display_name": row[3],
        "avatar_url": row[4],
        "role": row[5],
        "credits": row[6],
        "is_active": row[7],
        "created_at": row[8].isoformat() if row[8] else None,
        "last_login_at": row[9].isoformat() if row[9] else None,
    }


def upsert_user_from_google(
    google_sub: str, email: str, display_name: str, avatar_url: str,
    admin_emails: List[str]
) -> Dict[str, Any]:
    """Create or update a user at login. Applies ADMIN_EMAILS bootstrap."""
    is_admin = email.lower() in [e.strip().lower() for e in admin_emails if e.strip()]
    with storage._pg() as conn:
        with conn.cursor() as cur:
            cur.execute(
                f"""
                INSERT INTO users (google_sub, email, display_name, avatar_url, role, last_login_at)
                VALUES (%s, %s, %s, %s, %s, now())
                ON CONFLICT (google_sub) DO UPDATE SET
                    email = EXCLUDED.email,
                    display_name = EXCLUDED.display_name,
                    avatar_url = EXCLUDED.avatar_url,
                    last_login_at = now(),
                    role = CASE WHEN %s THEN 'admin' ELSE users.role END
                RETURNING {_USER_COLS}
                """,
                (google_sub, email, display_name, avatar_url,
                 'admin' if is_admin else 'user', is_admin),
            )
            return _row_to_user(cur.fetchone())


def get_user(user_id: str) -> Optional[Dict[str, Any]]:
    with storage._pg() as conn:
        with conn.cursor() as cur:
            cur.execute(f"SELECT {_USER_COLS} FROM users WHERE id = %s", (user_id,))
            row = cur.fetchone()
            return _row_to_user(row) if row else None


def list_users(search: str = "", limit: int = 50, offset: int = 0) -> Dict[str, Any]:
    with storage._pg() as conn:
        with conn.cursor() as cur:
            where, params = "", []
            if search:
                where = "WHERE email ILIKE %s OR display_name ILIKE %s"
                params = [f"%{search}%", f"%{search}%"]
            cur.execute(f"SELECT count(*) FROM users {where}", params)
            total = cur.fetchone()[0]
            cur.execute(
                f"""
                SELECT {_USER_COLS},
                       (SELECT count(*) FROM credit_transactions t
                        WHERE t.user_id = users.id AND t.kind = 'usage') AS request_count
                FROM users {where}
                ORDER BY created_at DESC
                LIMIT %s OFFSET %s
                """,
                params + [limit, offset],
            )
            users = []
            for row in cur.fetchall():
                u = _row_to_user(row[:10])
                u["request_count"] = row[10]
                users.append(u)
            return {"total": total, "users": users}


def update_user(user_id: str, is_active: Optional[bool] = None,
                role: Optional[str] = None) -> Optional[Dict[str, Any]]:
    sets, params = [], []
    if is_active is not None:
        sets.append("is_active = %s")
        params.append(is_active)
    if role is not None:
        sets.append("role = %s")
        params.append(role)
    if not sets:
        return get_user(user_id)
    params.append(user_id)
    with storage._pg() as conn:
        with conn.cursor() as cur:
            cur.execute(
                f"UPDATE users SET {', '.join(sets)} WHERE id = %s RETURNING {_USER_COLS}",
                params,
            )
            row = cur.fetchone()
            return _row_to_user(row) if row else None


# ---------------------------------------------------------------------------
# Credits — ATOMIC operations (debit + ledger line in the SAME transaction)
# ---------------------------------------------------------------------------

class InsufficientCredits(Exception):
    def __init__(self, required: int, balance: int):
        self.required = required
        self.balance = balance
        super().__init__(f"insufficient credits: required {required}, balance {balance}")


def debit_credits(user_id: str, cost: int, conversation_id: str) -> int:
    """Atomically debit `cost` credits. Raises InsufficientCredits on failure.

    Uses a single conditional UPDATE — never check-then-update.
    Returns the balance after the debit.
    """
    with storage._pg() as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                UPDATE users SET credits = credits - %s
                WHERE id = %s AND credits >= %s AND is_active
                RETURNING credits
                """,
                (cost, user_id, cost),
            )
            row = cur.fetchone()
            if row is None:
                # Read current balance for the error payload (separate read is
                # fine here — we already refused the debit)
                cur.execute("SELECT credits FROM users WHERE id = %s", (user_id,))
                bal_row = cur.fetchone()
                raise InsufficientCredits(cost, bal_row[0] if bal_row else 0)
            balance_after = row[0]
            cur.execute(
                """
                INSERT INTO credit_transactions
                    (user_id, amount, kind, conversation_id, balance_after)
                VALUES (%s, %s, 'usage', %s, %s)
                """,
                (user_id, -cost, conversation_id, balance_after),
            )
            return balance_after


def credit_account(
    user_id: str, amount: int, kind: str,
    paypal_order_id: Optional[str] = None,
    paypal_capture_id: Optional[str] = None,
    conversation_id: Optional[str] = None,
    note: Optional[str] = None,
) -> Optional[int]:
    """Atomically credit an account + ledger line.

    Idempotent for purchases: the partial unique index on paypal_order_id
    makes a replayed order a no-op (returns None).
    Also used for kind='refund' and kind='admin_grant' (amount may be negative
    for an admin deduction — floor at 0 via GREATEST).
    """
    import psycopg2
    try:
        with storage._pg() as conn:
            with conn.cursor() as cur:
                # Insert the ledger line FIRST so the unique index rejects
                # replays before any balance change.
                cur.execute(
                    """
                    INSERT INTO credit_transactions
                        (user_id, amount, kind, paypal_order_id, paypal_capture_id,
                         conversation_id, note, balance_after)
                    VALUES (%s, %s, %s, %s, %s, %s, %s, 0)
                    RETURNING id
                    """,
                    (user_id, amount, kind, paypal_order_id, paypal_capture_id,
                     conversation_id, note),
                )
                tx_id = cur.fetchone()[0]
                cur.execute(
                    """
                    UPDATE users SET credits = GREATEST(credits + %s, 0)
                    WHERE id = %s RETURNING credits
                    """,
                    (amount, user_id),
                )
                balance_after = cur.fetchone()[0]
                cur.execute(
                    "UPDATE credit_transactions SET balance_after = %s WHERE id = %s",
                    (balance_after, tx_id),
                )
                return balance_after
    except psycopg2.errors.UniqueViolation:
        logger.warning("credit_account: duplicate paypal_order_id %s — ignored (idempotent)",
                       paypal_order_id)
        return None
    except psycopg2.IntegrityError:
        logger.warning("credit_account: integrity error for order %s — ignored", paypal_order_id)
        return None


def list_transactions(user_id: Optional[str] = None, limit: int = 50) -> List[Dict[str, Any]]:
    with storage._pg() as conn:
        with conn.cursor() as cur:
            if user_id:
                cur.execute(
                    """
                    SELECT t.id, t.user_id, u.email, t.amount, t.kind, t.paypal_order_id,
                           t.conversation_id, t.note, t.balance_after, t.created_at
                    FROM credit_transactions t JOIN users u ON u.id = t.user_id
                    WHERE t.user_id = %s ORDER BY t.created_at DESC LIMIT %s
                    """,
                    (user_id, limit),
                )
            else:
                cur.execute(
                    """
                    SELECT t.id, t.user_id, u.email, t.amount, t.kind, t.paypal_order_id,
                           t.conversation_id, t.note, t.balance_after, t.created_at
                    FROM credit_transactions t JOIN users u ON u.id = t.user_id
                    ORDER BY t.created_at DESC LIMIT %s
                    """,
                    (limit,),
                )
            return [
                {
                    "id": str(r[0]), "user_id": str(r[1]), "email": r[2],
                    "amount": r[3], "kind": r[4], "paypal_order_id": r[5],
                    "conversation_id": r[6], "note": r[7], "balance_after": r[8],
                    "created_at": r[9].isoformat() if r[9] else None,
                }
                for r in cur.fetchall()
            ]


# ---------------------------------------------------------------------------
# Stats (admin dashboard)
# ---------------------------------------------------------------------------

def get_stats() -> Dict[str, Any]:
    with storage._pg() as conn:
        with conn.cursor() as cur:
            cur.execute("SELECT count(*) FROM users WHERE is_active")
            active_users = cur.fetchone()[0]
            cur.execute(
                "SELECT coalesce(sum(amount), 0) FROM credit_transactions WHERE kind = 'purchase'"
            )
            credits_sold = cur.fetchone()[0]
            cur.execute(
                "SELECT coalesce(-sum(amount), 0) FROM credit_transactions WHERE kind = 'usage'"
            )
            credits_used = cur.fetchone()[0]
            cur.execute(
                """SELECT count(*) FROM credit_transactions
                   WHERE kind = 'usage' AND created_at > now() - interval '7 days'"""
            )
            requests_7d = cur.fetchone()[0]
            cur.execute(
                """SELECT count(*) FROM credit_transactions
                   WHERE kind = 'usage' AND created_at > now() - interval '30 days'"""
            )
            requests_30d = cur.fetchone()[0]
            # Revenue: map purchased credits back to pack prices is approximate;
            # store real revenue by summing pack price at purchase time via note.
            cur.execute(
                """SELECT coalesce(sum((note::jsonb->>'price_cad')::numeric), 0)
                   FROM credit_transactions
                   WHERE kind = 'purchase' AND note IS NOT NULL AND note::jsonb ? 'price_cad'"""
            )
            revenue_cad = float(cur.fetchone()[0])
    return {
        "active_users": active_users,
        "credits_sold": credits_sold,
        "credits_used": credits_used,
        "requests_7d": requests_7d,
        "requests_30d": requests_30d,
        "revenue_cad": revenue_cad,
    }
