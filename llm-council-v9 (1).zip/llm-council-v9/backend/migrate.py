"""v9 — Release-phase migration runner (Procfile: release)."""
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from backend import db  # noqa: E402

if __name__ == "__main__":
    db.run_migrations()
    print("Migrations v9 appliquées.")
