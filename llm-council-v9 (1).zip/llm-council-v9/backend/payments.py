"""v9 — PayPal Checkout: prepaid credit packs.

Server-authoritative amounts: pack prices are ALWAYS read from
app_settings — never trusted from the client payload.
Idempotent crediting via the unique index on paypal_order_id.
Webhook signature verification via PayPal's verify-webhook-signature API.
"""

import os
import json
import logging
from typing import Dict, Any, Optional

import httpx
from fastapi import APIRouter, Request, HTTPException, Depends

logger = logging.getLogger(__name__)

try:
    from . import db
    from .auth import get_current_user
except ImportError:
    import db
    from auth import get_current_user

PAYPAL_CLIENT_ID = os.getenv("PAYPAL_CLIENT_ID", "")
PAYPAL_CLIENT_SECRET = os.getenv("PAYPAL_CLIENT_SECRET", "")
PAYPAL_MODE = os.getenv("PAYPAL_MODE", "sandbox")
PAYPAL_WEBHOOK_ID = os.getenv("PAYPAL_WEBHOOK_ID", "")

PAYPAL_BASE = (
    "https://api-m.paypal.com" if PAYPAL_MODE == "live"
    else "https://api-m.sandbox.paypal.com"
)

PAYMENTS_ENABLED = bool(db.USE_PG and PAYPAL_CLIENT_ID and PAYPAL_CLIENT_SECRET)

router = APIRouter(prefix="/api/payments", tags=["payments"])


# ---------------------------------------------------------------------------
# PayPal API helpers
# ---------------------------------------------------------------------------

async def _paypal_token() -> str:
    async with httpx.AsyncClient(timeout=30.0) as client:
        resp = await client.post(
            f"{PAYPAL_BASE}/v1/oauth2/token",
            auth=(PAYPAL_CLIENT_ID, PAYPAL_CLIENT_SECRET),
            data={"grant_type": "client_credentials"},
        )
        resp.raise_for_status()
        return resp.json()["access_token"]


def _find_pack(pack_id: str) -> Optional[Dict[str, Any]]:
    packs = db.get_setting("credit_packs", [])
    for p in packs:
        if p.get("id") == pack_id:
            return p
    return None


# ---------------------------------------------------------------------------
# Routes
# ---------------------------------------------------------------------------

@router.get("/packs")
async def get_packs(user=Depends(get_current_user)):
    return {
        "packs": db.get_setting("credit_packs", []),
        "request_cost": db.get_setting("request_cost", {"standard": 10, "vision": 15}),
        "payments_enabled": PAYMENTS_ENABLED,
        "paypal_client_id": PAYPAL_CLIENT_ID if PAYMENTS_ENABLED else None,
        "paypal_mode": PAYPAL_MODE,
        "currency": "CAD",
    }


@router.post("/orders")
async def create_order(payload: Dict[str, Any], user=Depends(get_current_user)):
    """Create a PayPal order for a pack. Amount read server-side ONLY."""
    if not PAYMENTS_ENABLED:
        raise HTTPException(status_code=503, detail="Paiements non configurés")
    pack = _find_pack(payload.get("pack_id", ""))
    if not pack:
        raise HTTPException(status_code=400, detail="Pack inconnu")

    token = await _paypal_token()
    order_body = {
        "intent": "CAPTURE",
        "purchase_units": [{
            "reference_id": pack["id"],
            "description": f"LLM Council — Pack {pack['name']} ({pack['credits']} crédits)",
            "custom_id": user["id"],
            "amount": {
                "currency_code": "CAD",
                "value": f"{float(pack['price_cad']):.2f}",
            },
        }],
    }
    async with httpx.AsyncClient(timeout=30.0) as client:
        resp = await client.post(
            f"{PAYPAL_BASE}/v2/checkout/orders",
            headers={"Authorization": f"Bearer {token}"},
            json=order_body,
        )
    if resp.status_code not in (200, 201):
        logger.error("PayPal create order failed: %s %s", resp.status_code, resp.text[:300])
        raise HTTPException(status_code=502, detail="Création de l'ordre PayPal échouée")
    data = resp.json()
    return {"order_id": data["id"]}


async def _credit_from_capture(order_data: Dict[str, Any]) -> Optional[int]:
    """Validate a captured order against the pack and credit the account.

    Returns the new balance, or None if already credited (idempotent replay).
    """
    pu = order_data["purchase_units"][0]
    pack_id = pu.get("reference_id")
    user_id = pu.get("custom_id") or (
        pu.get("payments", {}).get("captures", [{}])[0].get("custom_id")
    )
    pack = _find_pack(pack_id)
    if not pack or not user_id:
        logger.error("Capture validation failed: pack=%s user=%s", pack_id, user_id)
        return None

    captures = pu.get("payments", {}).get("captures", [])
    if not captures:
        return None
    capture = captures[0]
    if capture.get("status") != "COMPLETED":
        return None
    amt = capture.get("amount", {})
    if amt.get("currency_code") != "CAD" or \
            abs(float(amt.get("value", 0)) - float(pack["price_cad"])) > 0.01:
        logger.error(
            "Capture amount mismatch: got %s %s, expected %.2f CAD",
            amt.get("value"), amt.get("currency_code"), float(pack["price_cad"])
        )
        return None

    return db.credit_account(
        user_id=user_id,
        amount=int(pack["credits"]),
        kind="purchase",
        paypal_order_id=order_data["id"],
        paypal_capture_id=capture.get("id"),
        note=json.dumps({"pack_id": pack_id, "price_cad": float(pack["price_cad"])}),
    )


@router.post("/orders/{order_id}/capture")
async def capture_order(order_id: str, user=Depends(get_current_user)):
    """Capture the approved order at PayPal and credit the account."""
    if not PAYMENTS_ENABLED:
        raise HTTPException(status_code=503, detail="Paiements non configurés")
    token = await _paypal_token()
    async with httpx.AsyncClient(timeout=30.0) as client:
        resp = await client.post(
            f"{PAYPAL_BASE}/v2/checkout/orders/{order_id}/capture",
            headers={"Authorization": f"Bearer {token}",
                     "Content-Type": "application/json"},
        )
    if resp.status_code not in (200, 201):
        # Order may already be captured (e.g. webhook won the race)
        if resp.status_code == 422 and "ORDER_ALREADY_CAPTURED" in resp.text:
            fresh = db.get_user(user["id"])
            return {"status": "COMPLETED", "balance": fresh["credits"] if fresh else None,
                    "already_captured": True}
        logger.error("PayPal capture failed: %s %s", resp.status_code, resp.text[:300])
        raise HTTPException(status_code=502, detail="Capture PayPal échouée")
    data = resp.json()
    if data.get("status") != "COMPLETED":
        raise HTTPException(status_code=402, detail=f"Paiement non complété: {data.get('status')}")

    balance = await _credit_from_capture(data)
    fresh = db.get_user(user["id"])
    return {
        "status": "COMPLETED",
        "balance": fresh["credits"] if fresh else balance,
        "already_captured": balance is None,
    }


@router.post("/webhook")
async def paypal_webhook(request: Request):
    """PAYMENT.CAPTURE.COMPLETED safety net with signature verification."""
    if not PAYMENTS_ENABLED:
        raise HTTPException(status_code=503, detail="Paiements non configurés")

    body_bytes = await request.body()
    try:
        event = json.loads(body_bytes)
    except json.JSONDecodeError:
        raise HTTPException(status_code=400, detail="Corps invalide")

    # --- Verify the webhook signature via PayPal's API ---
    if PAYPAL_WEBHOOK_ID:
        verify_body = {
            "auth_algo": request.headers.get("paypal-auth-algo"),
            "cert_url": request.headers.get("paypal-cert-url"),
            "transmission_id": request.headers.get("paypal-transmission-id"),
            "transmission_sig": request.headers.get("paypal-transmission-sig"),
            "transmission_time": request.headers.get("paypal-transmission-time"),
            "webhook_id": PAYPAL_WEBHOOK_ID,
            "webhook_event": event,
        }
        token = await _paypal_token()
        async with httpx.AsyncClient(timeout=30.0) as client:
            resp = await client.post(
                f"{PAYPAL_BASE}/v1/notifications/verify-webhook-signature",
                headers={"Authorization": f"Bearer {token}"},
                json=verify_body,
            )
        if resp.status_code != 200 or resp.json().get("verification_status") != "SUCCESS":
            logger.warning("Webhook signature verification FAILED")
            raise HTTPException(status_code=401, detail="Signature webhook invalide")
    else:
        logger.warning("PAYPAL_WEBHOOK_ID not set — webhook signature NOT verified")

    if event.get("event_type") != "PAYMENT.CAPTURE.COMPLETED":
        return {"ok": True, "ignored": event.get("event_type")}

    # Fetch the full order to reuse the same validation path as /capture
    resource = event.get("resource", {})
    order_id = None
    for link in resource.get("links", []):
        if link.get("rel") == "up" and "/checkout/orders/" in link.get("href", ""):
            order_id = link["href"].rstrip("/").split("/")[-1]
            break
    if not order_id:
        order_id = resource.get("supplementary_data", {}) \
                           .get("related_ids", {}).get("order_id")
    if not order_id:
        logger.error("Webhook: unable to resolve order_id from event")
        return {"ok": False}

    token = await _paypal_token()
    async with httpx.AsyncClient(timeout=30.0) as client:
        resp = await client.get(
            f"{PAYPAL_BASE}/v2/checkout/orders/{order_id}",
            headers={"Authorization": f"Bearer {token}"},
        )
    if resp.status_code != 200:
        logger.error("Webhook: failed to fetch order %s", order_id)
        return {"ok": False}

    await _credit_from_capture(resp.json())
    return {"ok": True}


@router.get("/transactions")
async def my_transactions(user=Depends(get_current_user)):
    if not db.USE_PG:
        return {"transactions": []}
    return {"transactions": db.list_transactions(user_id=user["id"], limit=50)}
