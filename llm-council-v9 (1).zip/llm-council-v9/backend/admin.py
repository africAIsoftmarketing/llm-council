"""v9 — Admin panel API. Every endpoint enforces role='admin' server-side."""

import logging
from typing import Dict, Any, Optional, List

from fastapi import APIRouter, HTTPException, Depends, Query
from pydantic import BaseModel

logger = logging.getLogger(__name__)

try:
    from . import db
    from .auth import get_current_admin
    from .openrouter import query_model
except ImportError:
    import db
    from auth import get_current_admin
    from openrouter import query_model

router = APIRouter(prefix="/api/admin", tags=["admin"],
                   dependencies=[Depends(get_current_admin)])


# ---------------------------------------------------------------------------
# Models management
# ---------------------------------------------------------------------------

class AddModelRequest(BaseModel):
    model_id: str


class ChairmanRequest(BaseModel):
    model_id: str


@router.get("/models")
async def get_models():
    return {
        "council_models": db.get_setting("council_models", []),
        "chairman_model": db.get_setting("chairman_model", ""),
    }


@router.post("/models")
async def add_model(req: AddModelRequest, admin=Depends(get_current_admin)):
    model_id = req.model_id.strip()
    if not model_id or "/" not in model_id:
        raise HTTPException(status_code=400,
                            detail="Identifiant invalide (format attendu: provider/model)")
    models: List[str] = list(db.get_setting("council_models", []))
    if model_id in models:
        raise HTTPException(status_code=409, detail="Modèle déjà présent")

    # Validate with a minimal OpenRouter call before saving
    test = await query_model(
        model_id,
        [{"role": "user", "content": "Reply with the single word: OK"}],
        timeout=30.0,
    )
    if test is None or not test.get("content"):
        raise HTTPException(
            status_code=422,
            detail=f"Le modèle '{model_id}' n'a pas répondu au test OpenRouter — non enregistré."
        )

    models.append(model_id)
    db.set_setting("council_models", models, updated_by=admin["id"])
    return {"council_models": models, "validated": True}


@router.delete("/models/{model_id:path}")
async def delete_model(model_id: str, admin=Depends(get_current_admin)):
    models: List[str] = list(db.get_setting("council_models", []))
    if model_id not in models:
        raise HTTPException(status_code=404, detail="Modèle introuvable")
    if len(models) <= 2:
        raise HTTPException(status_code=400,
                            detail="Minimum 2 modèles requis dans le council")
    models.remove(model_id)
    db.set_setting("council_models", models, updated_by=admin["id"])
    # If the chairman was this model, fall back to the first remaining one
    if db.get_setting("chairman_model") == model_id:
        db.set_setting("chairman_model", models[0], updated_by=admin["id"])
    return {"council_models": models}


@router.put("/chairman")
async def set_chairman(req: ChairmanRequest, admin=Depends(get_current_admin)):
    model_id = req.model_id.strip()
    models = db.get_setting("council_models", [])
    if model_id not in models:
        raise HTTPException(status_code=400,
                            detail="Le chairman doit faire partie des modèles du council")
    db.set_setting("chairman_model", model_id, updated_by=admin["id"])
    return {"chairman_model": model_id}


# ---------------------------------------------------------------------------
# Users management
# ---------------------------------------------------------------------------

class PatchUserRequest(BaseModel):
    is_active: Optional[bool] = None
    role: Optional[str] = None


class CreditsAdjustRequest(BaseModel):
    amount: int
    reason: str = ""


@router.get("/users")
async def get_users(search: str = Query(""), limit: int = Query(50, le=200),
                    offset: int = Query(0, ge=0)):
    if not db.USE_PG:
        return {"total": 0, "users": []}
    return db.list_users(search=search, limit=limit, offset=offset)


@router.patch("/users/{user_id}")
async def patch_user(user_id: str, req: PatchUserRequest, admin=Depends(get_current_admin)):
    if req.role is not None and req.role not in ("user", "admin"):
        raise HTTPException(status_code=400, detail="Rôle invalide")
    if user_id == admin["id"] and req.role == "user":
        raise HTTPException(status_code=400,
                            detail="Impossible de rétrograder votre propre compte")
    if user_id == admin["id"] and req.is_active is False:
        raise HTTPException(status_code=400,
                            detail="Impossible de désactiver votre propre compte")
    user = db.update_user(user_id, is_active=req.is_active, role=req.role)
    if user is None:
        raise HTTPException(status_code=404, detail="Utilisateur introuvable")
    return user


@router.post("/users/{user_id}/credits")
async def adjust_credits(user_id: str, req: CreditsAdjustRequest,
                         admin=Depends(get_current_admin)):
    if req.amount == 0:
        raise HTTPException(status_code=400, detail="Montant nul")
    target = db.get_user(user_id)
    if target is None:
        raise HTTPException(status_code=404, detail="Utilisateur introuvable")
    balance = db.credit_account(
        user_id=user_id,
        amount=req.amount,
        kind="admin_grant",
        note=f"admin:{admin['email']} — {req.reason}",
    )
    return {"user_id": user_id, "balance": balance}


# ---------------------------------------------------------------------------
# Settings (pricing)
# ---------------------------------------------------------------------------

ALLOWED_SETTINGS = {"credit_packs", "request_cost", "council_models", "chairman_model"}


class SettingUpdateRequest(BaseModel):
    value: Any


@router.get("/settings")
async def get_settings():
    return {k: db.get_setting(k) for k in ALLOWED_SETTINGS}


@router.put("/settings/{key}")
async def put_setting(key: str, req: SettingUpdateRequest, admin=Depends(get_current_admin)):
    if key not in ALLOWED_SETTINGS:
        raise HTTPException(status_code=400, detail=f"Clé non modifiable: {key}")
    # Minimal shape validation
    if key == "credit_packs":
        if not isinstance(req.value, list) or not req.value:
            raise HTTPException(status_code=400, detail="credit_packs doit être une liste non vide")
        for p in req.value:
            if not all(k in p for k in ("id", "name", "price_cad", "credits")):
                raise HTTPException(status_code=400,
                                    detail="Chaque pack requiert id, name, price_cad, credits")
            if float(p["price_cad"]) <= 0 or int(p["credits"]) <= 0:
                raise HTTPException(status_code=400, detail="Prix et crédits doivent être > 0")
    if key == "request_cost":
        if not isinstance(req.value, dict) or \
                "standard" not in req.value or "vision" not in req.value:
            raise HTTPException(status_code=400,
                                detail="request_cost requiert les clés standard et vision")
        if int(req.value["standard"]) <= 0 or int(req.value["vision"]) <= 0:
            raise HTTPException(status_code=400, detail="Les coûts doivent être > 0")
    db.set_setting(key, req.value, updated_by=admin["id"])
    return {key: req.value}


# ---------------------------------------------------------------------------
# Stats
# ---------------------------------------------------------------------------

@router.get("/stats")
async def get_stats():
    if not db.USE_PG:
        return {"active_users": 0, "credits_sold": 0, "credits_used": 0,
                "requests_7d": 0, "requests_30d": 0, "revenue_cad": 0,
                "transactions": []}
    stats = db.get_stats()
    stats["transactions"] = db.list_transactions(limit=50)
    return stats
