# LLM Council v9 — Guide de déploiement (monétisation)

Version SaaS : Google SSO, crédits prépayés PayPal (pay-per-request), panneau
d'administration. Backend FastAPI + frontend React servi statiquement, single-dyno
Heroku, Postgres pour comptes / crédits / transactions / conversations.

---

## 1. Ce que fait la v9

- **Authentification** : Google SSO uniquement (pas de mot de passe). Session par
  JWT signé en cookie httpOnly (7 jours). Un visiteur non connecté ne voit que `/login`.
- **Crédits prépayés** : l'utilisateur achète un pack via PayPal (transaction unique),
  puis chaque requête au council débite des crédits. Solde visible en permanence dans
  la barre du haut. Requête refusée (HTTP 402) si solde insuffisant → modal d'achat.
- **Barème par défaut** (modifiable dans l'admin, sans redéploiement) :

  | Pack | Prix | Crédits |
  |------|------|---------|
  | Découverte | 5 CAD | 50 |
  | Standard | 15 CAD | 200 |
  | Pro | 40 CAD | 650 |

  Coût par requête : 10 crédits (standard), 15 crédits (avec images/vision).
- **Panneau admin** (`/admin`, réservé `role=admin`) : gestion des modèles du council
  (ajout avec validation OpenRouter, suppression, choix du chairman), des utilisateurs
  (crédits, activation, rôle), de la tarification, et statistiques (revenus, crédits
  consommés, utilisateurs actifs, volume de requêtes, 50 dernières transactions).

Le pipeline de délibération (`council.py`) est **inchangé** : mêmes rapports qu'en v8.

---

## 2. Variables d'environnement Heroku

```bash
# --- Authentification Google ---
heroku config:set GOOGLE_CLIENT_ID="xxxxx.apps.googleusercontent.com"
heroku config:set GOOGLE_CLIENT_SECRET="xxxxx"
heroku config:set JWT_SECRET="$(python3 -c 'import secrets; print(secrets.token_hex(32))')"  # 64 caractères
heroku config:set ADMIN_EMAILS="cedric@africaisoft.com"   # liste séparée par virgules

# --- Paiement PayPal ---
heroku config:set PAYPAL_CLIENT_ID="xxxxx"
heroku config:set PAYPAL_CLIENT_SECRET="xxxxx"
heroku config:set PAYPAL_MODE="sandbox"          # 'sandbox' puis 'live' en production
heroku config:set PAYPAL_WEBHOOK_ID="xxxxx"       # ID du webhook créé sur PayPal

# --- OpenRouter (déjà présent en v8) ---
heroku config:set OPENROUTER_API_KEY="sk-or-..."

# DATABASE_URL est fourni automatiquement par l'addon Postgres.
```

Ajout de l'addon Postgres (obligatoire) :

```bash
heroku addons:create heroku-postgresql:essential-0
```

`ADMIN_EMAILS` est le **seul** moyen de créer le premier admin : à la connexion, tout
email figurant dans cette liste passe automatiquement `role=admin`.

---

## 3. Configuration Google Cloud Console

1. https://console.cloud.google.com → **APIs & Services** → **OAuth consent screen**
   - Type « External », renseigner nom d'app / email de support.
   - Scopes : `openid`, `email`, `profile`.
   - En test : ajouter les comptes Google autorisés ; sinon publier l'app.
2. **Credentials** → **Create Credentials** → **OAuth client ID** → type « Web application ».
   - **Authorized redirect URI** :
     `https://<votre-app>.herokuapp.com/api/auth/callback`
   - Récupérer le *Client ID* et le *Client Secret* → variables ci-dessus.

---

## 4. Configuration PayPal

1. https://developer.paypal.com → **Apps & Credentials** (bascule Sandbox/Live).
2. Créer une app REST → récupérer *Client ID* et *Secret*.
3. **Webhooks** → ajouter un webhook :
   - URL : `https://<votre-app>.herokuapp.com/api/payments/webhook`
   - Événement : **`PAYMENT.CAPTURE.COMPLETED`**
   - Copier le *Webhook ID* → `PAYPAL_WEBHOOK_ID`.
4. Devise des packs : **CAD**. Vérifier que le compte marchand accepte le CAD.
5. Passage en production : `PAYPAL_MODE=live` + clés *live* + webhook *live*.

Le webhook est un filet de sécurité : si l'utilisateur ferme l'onglet entre
l'approbation et la capture, PayPal notifie le serveur qui crédite quand même
(idempotence garantie, pas de double-crédit).

---

## 5. Déploiement

```bash
git checkout -b v9-monetization
git add -A && git commit -m "v9 monétisation : SSO Google, crédits PayPal, admin"
git push heroku v9-monetization:main
```

Le `Procfile` exécute d'abord la phase *release* (migrations, idempotentes), puis
démarre le web :

```
release: python -m backend.migrate
web: uvicorn backend.main:app --host 0.0.0.0 --port $PORT --workers 1
```

Les migrations tournent aussi au démarrage de l'app — sans risque, elles sont
idempotentes (`CREATE TABLE IF NOT EXISTS`, `ADD COLUMN IF NOT EXISTS`, seed
`ON CONFLICT DO NOTHING`).

---

## 6. Mode « ouvert » (développement local)

Sans `DATABASE_URL` **ou** sans `GOOGLE_CLIENT_ID`, l'app démarre en **mode ouvert** :
authentification désactivée, un utilisateur dev local (`dev@localhost`, rôle admin,
crédits illimités), crédits non débités. Le développement local fonctionne donc sans
aucune configuration Google/PayPal. La production (variables présentes) applique
l'authentification et la facturation complètes.

---

## 7. Sécurité — points implémentés

- Montants et coûts **toujours** relus côté serveur depuis `app_settings` — jamais
  depuis le client.
- **Débit atomique** en SQL : `UPDATE ... WHERE credits >= cost AND is_active`
  (jamais de lecture-puis-écriture). Ligne de `credit_transactions` écrite dans la
  **même** transaction.
- **Idempotence** des crédits d'achat via index unique partiel sur `paypal_order_id` :
  un webhook rejoué ne crédite pas deux fois.
- **Vérification de signature** du webhook PayPal (API `verify-webhook-signature`).
- Tous les endpoints `/api/admin/*` vérifient `role=admin` côté backend.
- JWT en cookie httpOnly + SameSite=Lax + Secure (en prod), expiration 7 jours.
- Rate limiting 10 req/min/IP sur `/api/auth/*` et `/api/payments/*`.
- Remboursement automatique (`kind=refund`) si le pipeline échoue après le débit.
- Aucun secret dans le code — tout en variables d'environnement.

---

## 8. Écarts assumés par rapport à la spécification

Choix pragmatiques, équivalents plus simples et déjà intégrés au reste du projet :

- **psycopg2 (pool sync existant)** au lieu de SQLAlchemy async + asyncpg. Le projet
  utilisait déjà ce pool dans `storage.py` ; le réutiliser évite une seconde couche
  de connexion et garde le code homogène.
- **Migrations idempotentes maison** (`backend/migrate.py` + `db.run_migrations()`)
  au lieu d'Alembic. Suffisant pour ce schéma, pas de dépendance supplémentaire.
- **Rate limiter in-memory maison** au lieu de slowapi. 10 req/min/IP par fenêtre
  glissante, sur les préfixes sensibles.

Tout le reste suit la spec : schéma de tables, règles d'intégrité, endpoints,
barème, français d'abord, sandbox par défaut.

---

## 9. Tests financiers validés (Postgres réel, 10/10)

Migrations · bootstrap `ADMIN_EMAILS` · débit refusé à 0 · achat +50 · rejeu
`paypal_order_id` sans double-crédit · débit atomique + ledger · remboursement ·
**course 6 threads × débit 10 sur solde 50 → exactement 5 acceptés / 1 refusé /
solde 0** · settings cache + update · compte désactivé → débit refusé · stats
(revenus 5,00 CAD via `note.price_cad`).
