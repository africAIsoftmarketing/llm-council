import { useNavigate } from 'react-router-dom';
import { useAuth } from '../AuthContext';
import './TopBar.css';

export function TopBar() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  if (!user) return null;

  return (
    <div className="topbar">
      <div className="topbar-brand" onClick={() => navigate('/')}>LLM Council</div>
      <div className="topbar-right">
        <div className="topbar-credits" onClick={() => navigate('/credits')}
             title="Voir mes crédits et transactions">
          <span className="credits-icon">◆</span>
          <span className="credits-value">{user.credits}</span>
          <span className="credits-label">crédits</span>
        </div>
        <button className="topbar-btn buy" onClick={() => navigate('/credits')}>
          Acheter des crédits
        </button>
        {user.role === 'admin' && (
          <button className="topbar-btn" onClick={() => navigate('/admin')}>
            Admin
          </button>
        )}
        <div className="topbar-user" title={user.email}>
          {user.avatar_url
            ? <img src={user.avatar_url} alt="" className="topbar-avatar" referrerPolicy="no-referrer" />
            : <div className="topbar-avatar fallback">{(user.display_name || user.email)[0].toUpperCase()}</div>}
          <span className="topbar-name">{user.display_name || user.email}</span>
        </div>
        {user.auth_enabled && (
          <button className="topbar-btn logout" onClick={logout}>Déconnexion</button>
        )}
      </div>
    </div>
  );
}

export function InsufficientCreditsModal() {
  const { showCreditsModal, setShowCreditsModal, creditsModalInfo } = useAuth();
  const navigate = useNavigate();

  if (!showCreditsModal) return null;

  return (
    <div className="modal-overlay" onClick={() => setShowCreditsModal(false)}>
      <div className="modal-card" onClick={(e) => e.stopPropagation()}>
        <h3>Crédits insuffisants</h3>
        <p>
          Cette requête nécessite <strong>{creditsModalInfo?.required ?? '?'} crédits</strong>,
          mais votre solde est de <strong>{creditsModalInfo?.balance ?? 0} crédits</strong>.
        </p>
        <div className="modal-actions">
          <button className="modal-btn secondary" onClick={() => setShowCreditsModal(false)}>
            Plus tard
          </button>
          <button className="modal-btn primary" onClick={() => {
            setShowCreditsModal(false);
            navigate('/credits');
          }}>
            Acheter des crédits
          </button>
        </div>
      </div>
    </div>
  );
}
