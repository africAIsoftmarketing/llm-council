"""Paiements v9 — PayPal Checkout (crédits prépayés).

Règles non négociables appliquées ici :
* Le montant est TOUJOURS relu côté serveur depuis app_settings['credit_packs']
  — jamais depuis le payload client.
* Capture vérifiée : status COMPLETED + montant capturé == prix du pack.
* Crédit idempotent (index unique paypal_order_id) : capture ET webhook peuvent
  tous deux tenter le crédit, un seul passe.
* Webhook vérifié via l'API PayPal verify-webhook-signature.
"""

import os
import time
from typing import Any, Dict, Optional

import httpx
from fastapi import APIRouter, Depends, HTTPException, Request

try:
    from .auth import get_current_user, rate_limit
    from .db import get_setting
    from . import credits as credits_svc
except ImportError:
    from auth import get_current_user, rate_limit
    from db import get_setting
    import credits as credits_svc

router = APIRouter(prefix="/api/payments", tags=["payments"])

PAYPAL_MODE = os.getenv("PAYPAL_MODE", "sandbox").lower()
PAYPAL_BASE = (
    "https://api-m.paypal.com" if PAYPAL_MODE == "live"
    else "https://api-m.sandbox.paypal.com"
)
PAYPAL_CLIENT_ID = os.getenv("PAYPAL_CLIENT_ID", "")
PAYPAL_CLIENT_SECRET = os.getenv("PAYPAL_CLIENT_SECRET", "")
PAYPAL_WEBHOOK_ID = os.getenv("PAYPAL_WEBHOOK_ID", "")

_token_cache: Dict[str, Any] = {"token": None, "expires_at": 0.0}


def _require_config():
    if not (PAYPAL_CLIENT_ID and PAYPAL_CLIENT_SECRET):
        raise HTTPException(status_code=503, detail="PayPal non configuré")


async def _paypal_token() -> str:
    now = time.monotonic()
    if _token_cache["token"] and now < _token_cache["expires_at"] - 60:
        return _token_cache["token"]
    async with httpx.AsyncClient(timeout=20) as client:
        resp = await client.post(
            f"{PAYPAL_BASE}/v1/oauth2/token",
            auth=(PAYPAL_CLIENT_ID, PAYPAL_CLIENT_SECRET),
            data={"grant_type": "client_credentials"},
        )
    if resp.status_code != 200:
        raise HTTPException(status_code=502, detail="Échec d'authentification PayPal")
    data = resp.json()
    _token_cache["token"] = data["access_token"]
    _token_cache["expires_at"] = now + int(data.get("expires_in", 300))
    return _token_cache["token"]


def _get_pack(pack_id: str) -> Optional[Dict[str, Any]]:
    packs = get_setting("credit_packs", []) or []
    return next((p for p in packs if p.get("id") == pack_id), None)


# ===================== Endpoints =====================

@router.get("/config")
async def paypal_config(user: Dict = Depends(get_current_user)):
    """Client ID + mode pour initialiser le SDK JS PayPal côté frontend."""
    return {"client_id": PAYPAL_CLIENT_ID, "mode": PAYPAL_MODE, "currency": "CAD"}


@router.get("/packs")
async def list_packs(user: Dict = Depends(get_current_user)):
    return {"packs": get_setting("credit_packs", []) or []}


@router.get("/transactions")
async def my_transactions(user: Dict = Depends(get_current_user)):
    return {"transactions": credits_svc.list_transactions(user["id"], limit=50)}


@router.post("/orders", dependencies=[Depends(rate_limit("payments", 10))])
async def create_order(payload: Dict[str, Any], user: Dict = Depends(get_current_user)):
    _require_config()
    pack = _get_pack(str(payload.get("pack_id", "")))
    if pack is None:
        raise HTTPException(status_code=404, detail="Pack inconnu")

    token = await _paypal_token()
    body = {
        "intent": "CAPTURE",
        "purchase_units": [{
            "reference_id": pack["id"],
            # custom_id permet au webhook de retrouver utilisateur + pack
            # même si l'onglet est fermé entre approbation et capture.
            "custom_id": f"{user['id']}|{pack['id']}",
            "description": f"LLM Council — pack {pack['name']} ({pack['credits']} crédits)",
            "amount": {
                "currency_code": "CAD",
                "value": f"{float(pack['price_cad']):.2f}",  # relu serveur, jamais client
            },
        }],
    }
    async with httpx.AsyncClient(timeout=20) as client:
        resp = await client.post(
            f"{PAYPAL_BASE}/v2/checkout/orders",
            headers={"Authorization": f"Bearer {token}"},
            json=body,
        )
    if resp.status_code not in (200, 201):
        raise HTTPException(status_code=502, detail="Création de l'ordre PayPal refusée")
    return {"order_id": resp.json()["id"]}


@router.post("/orders/{order_id}/capture", dependencies=[Depends(rate_limit("payments", 10))])
async def capture_order(order_id: str, user: Dict = Depends(get_current_user)):
    _require_config()
    token = await _paypal_token()
    async with httpx.AsyncClient(timeout=30) as client:
        resp = await client.post(
            f"{PAYPAL_BASE}/v2/checkout/orders/{order_id}/capture",
            headers={"Authorization": f"Bearer {token}", "Content-Type": "application/json"},
        )
    data = resp.json() if resp.content else {}

    # Un rejeu de capture renvoie ORDER_ALREADY_CAPTURED : on relit l'ordre.
    if resp.status_code == 422 and any(
        d.get("issue") == "ORDER_ALREADY_CAPTURED" for d in data.get("details", [])
    ):
        async with httpx.AsyncClient(timeout=20) as client:
            resp = await client.get(
                f"{PAYPAL_BASE}/v2/checkout/orders/{order_id}",
                headers={"Authorization": f"Bearer {token}"},
            )
        data = resp.json()
    elif resp.status_code not in (200, 201):
        raise HTTPException(status_code=502, detail="Capture PayPal échouée")

    if data.get("status") != "COMPLETED":
        raise HTTPException(status_code=409, detail=f"Ordre non complété ({data.get('status')})")

    pu = (data.get("purchase_units") or [{}])[0]
    custom = pu.get("custom_id") or (pu.get("payments", {}).get("captures") or [{}])[0].get("custom_id", "")
    captures = pu.get("payments", {}).get("captures") or []
    capture = captures[0] if captures else {}
    captured_amount = capture.get("amount", {}) or pu.get("amount", {})

    owner_id, _, pack_id = (custom or "").partition("|")
    pack = _get_pack(pack_id or pu.get("reference_id", ""))
    if pack is None:
        raise HTTPException(status_code=409, detail="Pack introuvable pour cet ordre")
    if owner_id and owner_id != user["id"]:
        raise HTTPException(status_code=403, detail="Cet ordre appartient à un autre compte")

    # Vérification du montant capturé (protège contre un ordre modifié).
    if (captured_amount.get("currency_code") != "CAD"
            or abs(float(captured_amount.get("value", 0)) - float(pack["price_cad"])) > 0.001):
        raise HTTPException(status_code=409, detail="Montant capturé incohérent avec le pack")

    new_balance = credits_svc.credit(
        user["id"], int(pack["credits"]), kind="purchase",
        amount_cad=float(pack["price_cad"]),
        paypal_order_id=order_id,
        paypal_capture_id=capture.get("id"),
        note=f"Achat pack {pack['name']}",
    )
    if new_balance is None:
        # Déjà crédité (webhook passé avant) — répondre le solde courant.
        from .auth import get_user_by_id
        u = get_user_by_id(user["id"])
        return {"status": "already_credited", "credits": pack["credits"], "balance": u["credits"]}
    return {"status": "credited", "credits": pack["credits"], "balance": new_balance}


@router.post("/webhook")
async def paypal_webhook(request: Request):
    """Filet de sécurité : PAYMENT.CAPTURE.COMPLETED avec signature vérifiée.
    Crédite si la capture n'a pas déjà été traitée par l'endpoint /capture."""
    _require_config()
    if not PAYPAL_WEBHOOK_ID:
        raise HTTPException(status_code=503, detail="PAYPAL_WEBHOOK_ID non configuré")

    event = await request.json()
    h = request.headers
    verify_body = {
        "auth_algo": h.get("paypal-auth-algo"),
        "cert_url": h.get("paypal-cert-url"),
        "transmission_id": h.get("paypal-transmission-id"),
        "transmission_sig": h.get("paypal-transmission-sig"),
        "transmission_time": h.get("paypal-transmission-time"),
        "webhook_id": PAYPAL_WEBHOOK_ID,
        "webhook_event": event,
    }
    token = await _paypal_token()
    async with httpx.AsyncClient(timeout=20) as client:
        resp = await client.post(
            f"{PAYPAL_BASE}/v1/notifications/verify-webhook-signature",
            headers={"Authorization": f"Bearer {token}"},
            json=verify_body,
        )
    if resp.status_code != 200 or resp.json().get("verification_status") != "SUCCESS":
        raise HTTPException(status_code=400, detail="Signature webhook invalide")

    if event.get("event_type") != "PAYMENT.CAPTURE.COMPLETED":
        return {"status": "ignored"}

    resource = event.get("resource", {})
    custom = resource.get("custom_id", "")
    owner_id, _, pack_id = custom.partition("|")
    order_id = None
    for link in resource.get("links", []):
        if link.get("rel") == "up" and "/orders/" in link.get("href", ""):
            order_id = link["href"].rstrip("/").split("/")[-1]
    order_id = order_id or resource.get("supplementary_data", {}).get(
        "related_ids", {}).get("order_id")

    pack = _get_pack(pack_id)
    if not (owner_id and pack and order_id):
        return {"status": "ignored", "reason": "custom_id/order_id manquant"}

    amount = resource.get("amount", {})
    if (amount.get("currency_code") != "CAD"
            or abs(float(amount.get("value", 0)) - float(pack["price_cad"])) > 0.001):
        return {"status": "ignored", "reason": "montant incohérent"}

    result = credits_svc.credit(
        owner_id, int(pack["credits"]), kind="purchase",
        amount_cad=float(pack["price_cad"]),
        paypal_order_id=order_id,
        paypal_capture_id=resource.get("id"),
        note=f"Achat pack {pack['name']} (webhook)",
    )
    return {"status": "credited" if result is not None else "already_credited"}
