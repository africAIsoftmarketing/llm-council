"""Phase `release` Heroku : `python -m backend.migrate`.

Migrations idempotentes — sûres à ré-exécuter à chaque déploiement.
"""

try:
    from .db import run_migrations
except ImportError:
    from db import run_migrations

if __name__ == "__main__":
    run_migrations()
