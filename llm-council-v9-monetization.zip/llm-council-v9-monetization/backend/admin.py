"""Panneau administrateur v9 — tous les endpoints exigent role='admin'
côté backend (dépendance get_current_admin), le masquage frontend n'est
qu'un confort d'interface.
"""

import os
from typing import Any, Dict, Optional

import httpx
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel

try:
    from .auth import get_current_admin
    from .db import pg, get_setting, set_setting
    from . import credits as credits_svc
    from .config_manager import get_config, update_config, get_api_key
except ImportError:
    from auth import get_current_admin
    from db import pg, get_setting, set_setting
    import credits as credits_svc
    from config_manager import get_config, update_config, get_api_key

router = APIRouter(
    prefix="/api/admin", tags=["admin"],
    dependencies=[Depends(get_current_admin)],
)

OPENROUTER_URL = "https://openrouter.ai/api/v1/chat/completions"


# ===================== Modèles =====================

async def _validate_openrouter_model(model_id: str) -> Dict[str, Any]:
    """Mini-appel OpenRouter avant enregistrement — rejette les identifiants invalides."""
    api_key = get_api_key()
    if not api_key:
        return {"ok": False, "error": "Clé OpenRouter non configurée"}
    try:
        async with httpx.AsyncClient(timeout=30) as client:
            resp = await client.post(
                OPENROUTER_URL,
                headers={"Authorization": f"Bearer {api_key}"},
                json={
                    "model": model_id,
                    "messages": [{"role": "user", "content": "ping"}],
                    "max_tokens": 1,
                },
            )
        if resp.status_code == 200:
            return {"ok": True}
        detail = resp.json().get("error", {}).get("message", resp.text[:200])
        return {"ok": False, "error": f"OpenRouter a refusé le modèle : {detail}"}
    except Exception as e:
        return {"ok": False, "error": f"Test du modèle impossible : {e}"}


@router.get("/models")
async def list_models():
    cfg = get_config()
    return {
        "council_models": cfg.get("council_models", []),
        "chairman_model": cfg.get("chairman_model", ""),
    }


class AddModelRequest(BaseModel):
    model_id: str


@router.post("/models")
async def add_model(req: AddModelRequest):
    model_id = req.model_id.strip()
    if not model_id:
        raise HTTPException(status_code=400, detail="Identifiant vide")
    cfg = get_config()
    models = list(cfg.get("council_models", []))
    if model_id in models:
        raise HTTPException(status_code=409, detail="Modèle déjà présent")
    check = await _validate_openrouter_model(model_id)
    if not check["ok"]:
        raise HTTPException(status_code=422, detail=check["error"])
    models.append(model_id)
    update_config({"council_models": models})
    return {"council_models": models}


@router.delete("/models/{model_id:path}")
async def remove_model(model_id: str):
    cfg = get_config()
    models = list(cfg.get("council_models", []))
    if model_id not in models:
        raise HTTPException(status_code=404, detail="Modèle absent du council")
    if len(models) <= 2:
        raise HTTPException(status_code=409, detail="Minimum 2 modèles dans le council")
    models.remove(model_id)
    updates: Dict[str, Any] = {"council_models": models}
    if cfg.get("chairman_model") == model_id:
        updates["chairman_model"] = models[0]
    update_config(updates)
    return {"council_models": models, "chairman_model": updates.get("chairman_model", cfg.get("chairman_model"))}


class ChairmanRequest(BaseModel):
    model_id: str


@router.put("/chairman")
async def set_chairman(req: ChairmanRequest):
    cfg = get_config()
    if req.model_id not in cfg.get("council_models", []):
        check = await _validate_openrouter_model(req.model_id)
        if not check["ok"]:
            raise HTTPException(status_code=422, detail=check["error"])
    update_config({"chairman_model": req.model_id})
    return {"chairman_model": req.model_id}


# ===================== Utilisateurs =====================

@router.get("/users")
async def list_users(page: int = 1, per_page: int = 25, search: Optional[str] = None):
    page = max(1, page)
    per_page = min(100, max(1, per_page))
    where, params = "", []
    if search:
        where = "WHERE u.email ILIKE %s OR u.display_name ILIKE %s"
        params = [f"%{search}%", f"%{search}%"]
    with pg() as conn:
        with conn.cursor() as cur:
            cur.execute(f"SELECT count(*) FROM users u {where}", params)
            total = cur.fetchone()[0]
            cur.execute(
                f"""
                SELECT u.id, u.email, u.display_name, u.avatar_url, u.role,
                       u.credits, u.is_active, u.created_at, u.last_login_at,
                       (SELECT count(*) FROM credit_transactions t
                        WHERE t.user_id = u.id AND t.kind = 'usage') AS request_count
                FROM users u {where}
                ORDER BY u.created_at DESC
                LIMIT %s OFFSET %s
                """,
                params + [per_page, (page - 1) * per_page],
            )
            rows = cur.fetchall()
    users = [
        {
            "id": str(r[0]), "email": r[1], "display_name": r[2], "avatar_url": r[3],
            "role": r[4], "credits": r[5], "is_active": r[6],
            "created_at": r[7].isoformat() if r[7] else None,
            "last_login_at": r[8].isoformat() if r[8] else None,
            "request_count": r[9],
        }
        for r in rows
    ]
    return {"users": users, "total": total, "page": page, "per_page": per_page}


class PatchUserRequest(BaseModel):
    is_active: Optional[bool] = None
    role: Optional[str] = None


@router.patch("/users/{user_id}")
async def patch_user(user_id: str, req: PatchUserRequest,
                     admin: Dict = Depends(get_current_admin)):
    if req.role is not None and req.role not in ("user", "admin"):
        raise HTTPException(status_code=400, detail="Rôle invalide")
    if user_id == admin["id"] and (req.is_active is False or req.role == "user"):
        raise HTTPException(status_code=409, detail="Impossible de se désactiver ou se rétrograder soi-même")
    sets, params = [], []
    if req.is_active is not None:
        sets.append("is_active = %s"); params.append(req.is_active)
    if req.role is not None:
        sets.append("role = %s"); params.append(req.role)
    if not sets:
        raise HTTPException(status_code=400, detail="Aucun champ à modifier")
    params.append(user_id)
    with pg() as conn:
        with conn.cursor() as cur:
            cur.execute(f"UPDATE users SET {', '.join(sets)} WHERE id = %s RETURNING id", params)
            if cur.fetchone() is None:
                raise HTTPException(status_code=404, detail="Utilisateur introuvable")
    return {"success": True}


class AdjustCreditsRequest(BaseModel):
    delta: int
    note: str = ""


@router.post("/users/{user_id}/credits")
async def adjust_credits(user_id: str, req: AdjustCreditsRequest,
                         admin: Dict = Depends(get_current_admin)):
    try:
        balance = credits_svc.adjust(user_id, req.delta, req.note, admin["id"])
    except credits_svc.InsufficientCredits:
        raise HTTPException(status_code=409, detail="Le solde ne peut pas devenir négatif")
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    return {"balance": balance}


# ===================== Tarification / réglages =====================

ALLOWED_SETTINGS = {"credit_packs", "request_cost"}


@router.get("/settings")
async def get_settings():
    return {k: get_setting(k) for k in ALLOWED_SETTINGS}


@router.put("/settings/{key}")
async def put_setting(key: str, payload: Dict[str, Any],
                      admin: Dict = Depends(get_current_admin)):
    if key not in ALLOWED_SETTINGS:
        raise HTTPException(status_code=404, detail="Clé de réglage inconnue")
    value = payload.get("value")
    if key == "credit_packs":
        if (not isinstance(value, list) or not value
                or not all(isinstance(p, dict) and p.get("id") and
                           float(p.get("price_cad", 0)) > 0 and int(p.get("credits", 0)) > 0
                           for p in value)):
            raise HTTPException(status_code=422, detail="Packs invalides (id, price_cad > 0, credits > 0 requis)")
    if key == "request_cost":
        if (not isinstance(value, dict)
                or int(value.get("standard", 0)) <= 0 or int(value.get("vision", 0)) <= 0):
            raise HTTPException(status_code=422, detail="Coûts invalides (standard et vision > 0 requis)")
    set_setting(key, value, updated_by=admin["id"])
    return {key: value}


# ===================== Statistiques =====================

@router.get("/stats")
async def stats():
    with pg() as conn:
        with conn.cursor() as cur:
            cur.execute("""
                SELECT
                  COALESCE((SELECT sum(amount_cad) FROM credit_transactions WHERE kind='purchase'), 0),
                  COALESCE((SELECT -sum(amount) FROM credit_transactions WHERE kind='usage'), 0),
                  (SELECT count(*) FROM users WHERE is_active),
                  (SELECT count(*) FROM credit_transactions WHERE kind='usage'
                     AND created_at > now() - interval '7 days'),
                  (SELECT count(*) FROM credit_transactions WHERE kind='usage'
                     AND created_at > now() - interval '30 days')
            """)
            revenue, consumed, active_users, req_7d, req_30d = cur.fetchone()
            cur.execute("""
                SELECT t.created_at, u.email, t.kind, t.amount, t.amount_cad,
                       t.balance_after, t.note
                FROM credit_transactions t JOIN users u ON u.id = t.user_id
                ORDER BY t.created_at DESC LIMIT 50
            """)
            rows = cur.fetchall()
    return {
        "revenue_cad": float(revenue),
        "credits_consumed": int(consumed),
        "active_users": active_users,
        "requests_7d": req_7d,
        "requests_30d": req_30d,
        "recent_transactions": [
            {
                "created_at": r[0].isoformat(), "email": r[1], "kind": r[2],
                "amount": r[3], "amount_cad": float(r[4]) if r[4] is not None else None,
                "balance_after": r[5], "note": r[6],
            }
            for r in rows
        ],
    }
