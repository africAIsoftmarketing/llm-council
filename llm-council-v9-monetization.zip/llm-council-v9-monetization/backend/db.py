"""Couche base de données v9.

Pool psycopg2 partagé (mêmes primitives sync que storage.py — une seule couche
DB dans toute l'application, pas de mélange sync/async), migrations de schéma
idempotentes exécutées en phase `release` Heroku, et accès aux `app_settings`
avec cache mémoire 60 s.

Les migrations ADOPTENT le schéma v8 existant : la table `conversations`
(id TEXT PK, data JSONB, ...) créée par storage.py est conservée et étendue
avec une colonne `user_id` — jamais recréée.
"""

import json
import os
import time
import threading
from contextlib import contextmanager
from typing import Any, Dict, Optional

DATABASE_URL = os.getenv("DATABASE_URL")
USE_PG = bool(DATABASE_URL)

_POOL = None
_POOL_LOCK = threading.Lock()


def get_pool():
    """Pool de connexions partagé par toute l'app (storage, auth, credits...)."""
    global _POOL
    if _POOL is None:
        with _POOL_LOCK:
            if _POOL is None:
                from psycopg2 import pool as pgpool
                sslmode = os.getenv("DB_SSLMODE", "require")
                _POOL = pgpool.ThreadedConnectionPool(
                    1, int(os.getenv("DB_POOL_MAX", "10")),
                    dsn=DATABASE_URL, sslmode=sslmode,
                )
    return _POOL


@contextmanager
def pg():
    """Connexion transactionnelle : commit en sortie normale, rollback sinon."""
    pool = get_pool()
    conn = pool.getconn()
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        pool.putconn(conn)


# ===================== Migrations (idempotentes) =====================

MIGRATION_SQL = """
-- Adoption du schéma v8 : la table conversations existe peut-être déjà.
CREATE TABLE IF NOT EXISTS conversations (
    id TEXT PRIMARY KEY,
    data JSONB NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS users (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    google_sub TEXT UNIQUE NOT NULL,
    email TEXT UNIQUE NOT NULL,
    display_name TEXT,
    avatar_url TEXT,
    role TEXT NOT NULL DEFAULT 'user',
    credits INTEGER NOT NULL DEFAULT 0,
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    last_login_at TIMESTAMPTZ
);

CREATE TABLE IF NOT EXISTS credit_transactions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES users(id),
    amount INTEGER NOT NULL,
    kind TEXT NOT NULL,
    amount_cad NUMERIC,
    paypal_order_id TEXT,
    paypal_capture_id TEXT,
    conversation_id TEXT,
    note TEXT,
    balance_after INTEGER NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS app_settings (
    key TEXT PRIMARY KEY,
    value JSONB NOT NULL,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_by UUID REFERENCES users(id)
);

-- v8 -> v9 : rattacher les conversations à leur propriétaire.
-- Nullable : les conversations pré-v9 restent orphelines (visibles par les admins).
ALTER TABLE conversations ADD COLUMN IF NOT EXISTS user_id UUID REFERENCES users(id);

CREATE INDEX IF NOT EXISTS idx_conversations_user ON conversations (user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_tx_user ON credit_transactions (user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_tx_created ON credit_transactions (created_at DESC);

-- Idempotence PayPal : un ordre ne crédite qu'une seule fois, même si le
-- webhook est rejoué ou si capture + webhook arrivent tous les deux.
CREATE UNIQUE INDEX IF NOT EXISTS uq_tx_paypal_order
    ON credit_transactions (paypal_order_id) WHERE paypal_order_id IS NOT NULL;
"""

DEFAULT_SETTINGS = {
    "credit_packs": [
        {"id": "decouverte", "name": "Découverte", "price_cad": 5.00, "credits": 50},
        {"id": "standard", "name": "Standard", "price_cad": 15.00, "credits": 200},
        {"id": "pro", "name": "Pro", "price_cad": 40.00, "credits": 650},
    ],
    "request_cost": {"standard": 10, "vision": 15},
}


def run_migrations():
    """Applique le schéma et insère les réglages par défaut manquants."""
    if not USE_PG:
        raise RuntimeError(
            "DATABASE_URL est requis en v9 (Heroku Postgres). "
            "Le mode fichier JSON de v8 ne peut pas porter comptes et transactions."
        )
    from psycopg2.extras import Json
    with pg() as conn:
        with conn.cursor() as cur:
            cur.execute(MIGRATION_SQL)
            for key, value in DEFAULT_SETTINGS.items():
                cur.execute(
                    "INSERT INTO app_settings (key, value) VALUES (%s, %s) "
                    "ON CONFLICT (key) DO NOTHING",
                    (key, Json(value)),
                )
    print("Migrations v9 appliquées.")


# ===================== app_settings avec cache 60 s =====================

_settings_cache: Dict[str, Any] = {}
_settings_cache_at: Dict[str, float] = {}
_CACHE_TTL = 60.0


def get_setting(key: str, default: Any = None) -> Any:
    now = time.monotonic()
    if key in _settings_cache and now - _settings_cache_at.get(key, 0) < _CACHE_TTL:
        return _settings_cache[key]
    with pg() as conn:
        with conn.cursor() as cur:
            cur.execute("SELECT value FROM app_settings WHERE key = %s", (key,))
            row = cur.fetchone()
    value = row[0] if row else default
    _settings_cache[key] = value
    _settings_cache_at[key] = now
    return value


def set_setting(key: str, value: Any, updated_by: Optional[str] = None):
    from psycopg2.extras import Json
    with pg() as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                INSERT INTO app_settings (key, value, updated_at, updated_by)
                VALUES (%s, %s, now(), %s)
                ON CONFLICT (key) DO UPDATE
                    SET value = EXCLUDED.value, updated_at = now(),
                        updated_by = EXCLUDED.updated_by
                """,
                (key, Json(value), updated_by),
            )
    _settings_cache[key] = value
    _settings_cache_at[key] = time.monotonic()


def invalidate_setting(key: str):
    _settings_cache.pop(key, None)
    _settings_cache_at.pop(key, None)
