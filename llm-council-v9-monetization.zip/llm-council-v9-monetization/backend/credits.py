"""Mouvements de crédits v9 — règles d'intégrité.

* Débit ATOMIQUE : UPDATE ... WHERE credits >= coût ; 0 ligne = refus (402).
  Jamais de check-then-update en deux temps (race condition).
* Chaque mouvement écrit sa ligne credit_transactions (avec balance_after)
  dans la MÊME transaction SQL que la mise à jour du solde.
* Crédit d'achat idempotent via l'index unique partiel sur paypal_order_id.
"""

from typing import Any, Dict, List, Optional

try:
    from .db import pg, get_setting
except ImportError:
    from db import pg, get_setting


class InsufficientCredits(Exception):
    def __init__(self, required: int, balance: int):
        self.required = required
        self.balance = balance
        super().__init__(f"Crédits insuffisants : requis {required}, solde {balance}")


def get_request_cost(has_images: bool) -> int:
    cost = get_setting("request_cost", {"standard": 10, "vision": 15}) or {}
    return int(cost.get("vision", 15) if has_images else cost.get("standard", 10))


def debit(user_id: str, cost: int, conversation_id: Optional[str] = None) -> int:
    """Débite `cost` crédits. Retourne le solde restant, ou lève InsufficientCredits."""
    if cost <= 0:
        raise ValueError("Le coût doit être positif")
    with pg() as conn:
        with conn.cursor() as cur:
            cur.execute(
                "UPDATE users SET credits = credits - %s "
                "WHERE id = %s AND credits >= %s RETURNING credits",
                (cost, user_id, cost),
            )
            row = cur.fetchone()
            if row is None:
                cur.execute("SELECT credits FROM users WHERE id = %s", (user_id,))
                bal = cur.fetchone()
                raise InsufficientCredits(cost, bal[0] if bal else 0)
            balance_after = row[0]
            cur.execute(
                "INSERT INTO credit_transactions "
                "(user_id, amount, kind, conversation_id, balance_after) "
                "VALUES (%s, %s, 'usage', %s, %s)",
                (user_id, -cost, conversation_id, balance_after),
            )
    return balance_after


def credit(
    user_id: str,
    amount: int,
    kind: str,
    amount_cad: Optional[float] = None,
    paypal_order_id: Optional[str] = None,
    paypal_capture_id: Optional[str] = None,
    conversation_id: Optional[str] = None,
    note: Optional[str] = None,
) -> Optional[int]:
    """Crédite le compte. Retourne le nouveau solde, ou None si l'ordre PayPal
    a déjà été crédité (rejeu de webhook -> no-op grâce à l'index unique)."""
    if amount <= 0:
        raise ValueError("Le montant doit être positif")
    from psycopg2 import errors as pg_errors
    try:
        with pg() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    "UPDATE users SET credits = credits + %s WHERE id = %s RETURNING credits",
                    (amount, user_id),
                )
                row = cur.fetchone()
                if row is None:
                    raise ValueError(f"Utilisateur {user_id} introuvable")
                balance_after = row[0]
                cur.execute(
                    "INSERT INTO credit_transactions "
                    "(user_id, amount, kind, amount_cad, paypal_order_id, "
                    " paypal_capture_id, conversation_id, note, balance_after) "
                    "VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)",
                    (user_id, amount, kind, amount_cad, paypal_order_id,
                     paypal_capture_id, conversation_id, note, balance_after),
                )
        return balance_after
    except pg_errors.UniqueViolation:
        # Ordre déjà crédité : transaction annulée par rollback, solde intact.
        return None


def adjust(user_id: str, delta: int, note: str, admin_id: str) -> int:
    """Ajustement admin (+/-). Peut rendre le solde négatif ? Non : plancher à 0 refusé."""
    if delta == 0:
        raise ValueError("Delta nul")
    with pg() as conn:
        with conn.cursor() as cur:
            if delta < 0:
                cur.execute(
                    "UPDATE users SET credits = credits + %s "
                    "WHERE id = %s AND credits >= %s RETURNING credits",
                    (delta, user_id, -delta),
                )
            else:
                cur.execute(
                    "UPDATE users SET credits = credits + %s WHERE id = %s RETURNING credits",
                    (delta, user_id),
                )
            row = cur.fetchone()
            if row is None:
                raise InsufficientCredits(-delta, 0)
            balance_after = row[0]
            cur.execute(
                "INSERT INTO credit_transactions "
                "(user_id, amount, kind, note, balance_after) "
                "VALUES (%s, %s, 'admin_grant', %s, %s)",
                (user_id, delta, f"[admin {admin_id}] {note}", balance_after),
            )
    return balance_after


def refund(user_id: str, amount: int, conversation_id: str, note: str = "") -> int:
    """Remboursement automatique quand le pipeline échoue APRÈS débit."""
    return credit(
        user_id, amount, kind="refund",
        conversation_id=conversation_id,
        note=note or "Échec du pipeline council — remboursement automatique",
    )


def list_transactions(user_id: str, limit: int = 50) -> List[Dict[str, Any]]:
    with pg() as conn:
        with conn.cursor() as cur:
            cur.execute(
                "SELECT amount, kind, amount_cad, conversation_id, note, "
                "balance_after, created_at FROM credit_transactions "
                "WHERE user_id = %s ORDER BY created_at DESC LIMIT %s",
                (user_id, limit),
            )
            rows = cur.fetchall()
    return [
        {
            "amount": r[0], "kind": r[1],
            "amount_cad": float(r[2]) if r[2] is not None else None,
            "conversation_id": r[3], "note": r[4],
            "balance_after": r[5], "created_at": r[6].isoformat(),
        }
        for r in rows
    ]
