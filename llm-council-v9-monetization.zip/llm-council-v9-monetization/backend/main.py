"""FastAPI backend for LLM Council with configuration and document management."""

from fastapi import FastAPI, HTTPException, UploadFile, File, Form, Request, Depends
from fastapi.responses import JSONResponse
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse, FileResponse, HTMLResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
from typing import List, Dict, Any, Optional
from pathlib import Path
import uuid
import json
import asyncio
import os
import sys

# Handle imports for both module and direct execution
try:
    from . import storage
    from . import credits as credits_svc
    from .db import USE_PG, run_migrations
    from .auth import router as auth_router, get_current_user, get_current_admin
    from .payments import router as payments_router
    from .admin import router as admin_router
    from .council import (
        run_full_council, generate_conversation_title, 
        stage1_collect_responses, stage2_collect_rankings, 
        stage3_synthesize_final, calculate_aggregate_rankings
    )
    from .config_manager import (
        get_config, update_config, validate_api_key, get_available_models,
        add_custom_model, load_config, get_api_key, apply_config_to_env,
        test_lm_studio_connection, get_lm_studio_urls,
        get_advanced_config, save_advanced_config
    )
    from .document_processor import (
        process_uploaded_file, list_documents, get_document, 
        delete_document, toggle_document_active, get_active_documents_context,
        get_active_vision_images, SUPPORTED_EXTENSIONS
    )
except ImportError:
    import storage
    import credits as credits_svc
    from db import USE_PG, run_migrations
    from auth import router as auth_router, get_current_user, get_current_admin
    from payments import router as payments_router
    from admin import router as admin_router
    from council import (
        run_full_council, generate_conversation_title, 
        stage1_collect_responses, stage2_collect_rankings, 
        stage3_synthesize_final, calculate_aggregate_rankings
    )
    from config_manager import (
        get_config, update_config, validate_api_key, get_available_models,
        add_custom_model, load_config, get_api_key, apply_config_to_env,
        test_lm_studio_connection, get_lm_studio_urls,
        get_advanced_config, save_advanced_config
    )
    from document_processor import (
        process_uploaded_file, list_documents, get_document, 
        delete_document, toggle_document_active, get_active_documents_context,
        get_active_vision_images, SUPPORTED_EXTENSIONS
    )


app = FastAPI(title="LLM Council API")

# v9 : authentification, paiements, administration
app.include_router(auth_router)
app.include_router(payments_router)
app.include_router(admin_router)


# ===== Helper Functions =====

def requires_openrouter_key(advanced_config: Optional[Dict] = None) -> bool:
    """
    Return True if the request needs an OpenRouter API key.
    In LM Studio mode, no OpenRouter key is needed.
    In hybrid mode, key is needed only if any model uses OpenRouter.
    """
    if not advanced_config:
        return True  # Default mode is openrouter
    
    mode = advanced_config.get('mode', 'openrouter')
    
    if mode == 'lmstudio':
        return False
    
    if mode == 'hybrid':
        # Need key if any model or chairman uses openrouter
        models_cfg = advanced_config.get('models', {})
        has_openrouter_model = any(
            m.get('source', 'openrouter') == 'openrouter'
            for m in models_cfg.values()
        )
        chairman_source = advanced_config.get('chairman', {}).get('source', 'openrouter')
        return has_openrouter_model or chairman_source == 'openrouter'
    
    return True  # openrouter mode


# Enable CORS for local development
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://localhost:3000", "http://localhost:8001", "*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ===== Live council run hub (survives client refresh) =====
# Single uvicorn worker -> a module-level registry is sufficient. Each run is a
# detached asyncio task that persists progress incrementally and broadcasts SSE
# events to any subscribers (the original sender AND reconnecting tabs).
_run_hub: Dict[str, Dict[str, Any]] = {}


def _publish(conversation_id: str, event: Dict[str, Any]):
    hub = _run_hub.get(conversation_id)
    if not hub:
        return
    hub["events"].append(event)
    for q in list(hub["subscribers"]):
        try:
            q.put_nowait(event)
        except Exception:
            pass


async def _stream_from_hub(conversation_id: str):
    """Yield SSE events for a running council, replaying past events first."""
    hub = _run_hub.get(conversation_id)
    if not hub:
        # No live run -> client should rely on the persisted conversation state.
        yield f"data: {json.dumps({'type': 'complete'})}\n\n"
        return

    q: asyncio.Queue = asyncio.Queue()
    # Replay events that already happened so a reconnecting tab catches up.
    for event in list(hub["events"]):
        q.put_nowait(event)
    hub["subscribers"].add(q)
    try:
        while True:
            try:
                event = await asyncio.wait_for(q.get(), timeout=30)
            except asyncio.TimeoutError:
                yield ": keepalive\n\n"
                continue
            yield f"data: {json.dumps(event)}\n\n"
            if event.get("type") in ("complete", "error"):
                break
    finally:
        hub["subscribers"].discard(q)


async def _run_council_task(
    conversation_id: str,
    query_content: str,
    vision_images,
    advanced_config,
    is_first_message: bool,
    original_content: str,
    user_id: str = None,
    debited_cost: int = 0,
):
    """Run the 3-stage council detached from the request; persist each stage.

    v9 : le débit de crédits a eu lieu AVANT le lancement. Le pipeline tournant
    en tâche détachée, le remboursement automatique en cas d'échec doit vivre
    ICI (dans le gestionnaire d'erreur de la tâche), pas dans le handler HTTP.
    """
    try:
        title_task = None
        if is_first_message:
            title_task = asyncio.create_task(
                generate_conversation_title(original_content, advanced_config=advanced_config)
            )

        _publish(conversation_id, {"type": "stage1_start"})
        stage1_results = await stage1_collect_responses(
            query_content, vision_images=vision_images, advanced_config=advanced_config
        )
        storage.update_last_assistant_message(conversation_id, stage1=stage1_results)
        _publish(conversation_id, {"type": "stage1_complete", "data": stage1_results})

        _publish(conversation_id, {"type": "stage2_start"})
        stage2_results, label_to_model = await stage2_collect_rankings(
            query_content, stage1_results, advanced_config=advanced_config
        )
        aggregate_rankings = calculate_aggregate_rankings(stage2_results, label_to_model)
        metadata = {"label_to_model": label_to_model, "aggregate_rankings": aggregate_rankings}
        storage.update_last_assistant_message(conversation_id, stage2=stage2_results, metadata=metadata)
        _publish(conversation_id, {"type": "stage2_complete", "data": stage2_results, "metadata": metadata})

        _publish(conversation_id, {"type": "stage3_start"})
        stage3_result = await stage3_synthesize_final(
            query_content, stage1_results, stage2_results, advanced_config=advanced_config
        )
        storage.update_last_assistant_message(conversation_id, stage3=stage3_result, status="complete")
        _publish(conversation_id, {"type": "stage3_complete", "data": stage3_result})

        if title_task:
            try:
                title = await title_task
            except Exception as title_err:
                print(f"Title generation failed (non-fatal): {title_err}")
                title = original_content[:47] + "..." if len(original_content) > 50 else original_content
            storage.update_conversation_title(conversation_id, title)
            _publish(conversation_id, {"type": "title_complete", "data": {"title": title}})

        _publish(conversation_id, {"type": "complete"})
    except Exception as e:
        try:
            storage.update_last_assistant_message(conversation_id, status="error", error=str(e))
        except Exception:
            pass
        # Remboursement automatique : le pipeline a échoué après débit.
        if user_id and debited_cost > 0:
            try:
                credits_svc.refund(user_id, debited_cost, conversation_id,
                                   note=f"Échec du pipeline : {str(e)[:200]}")
                _publish(conversation_id, {"type": "refund", "amount": debited_cost})
            except Exception as refund_err:
                print(f"ERREUR remboursement {user_id} ({debited_cost} cr): {refund_err}")
        _publish(conversation_id, {"type": "error", "message": str(e)})
    finally:
        # Grace period so connected clients flush the terminal event, then clean up.
        await asyncio.sleep(3)
        _run_hub.pop(conversation_id, None)


# Determine frontend path
def get_frontend_path():
    """Get the path to frontend dist folder."""
    # Get the directory where this file is located
    backend_dir = Path(__file__).parent.resolve()
    
    # Check various possible locations
    possible_paths = [
        # Production: frontend dist is sibling to backend
        backend_dir.parent / "frontend" / "dist",
        backend_dir.parent / "frontend",
        # Development: frontend/dist relative to backend parent
        Path(os.getcwd()) / "frontend" / "dist",
        Path(os.getcwd()) / "frontend",
    ]
    
    for p in possible_paths:
        index_file = p / "index.html"
        if index_file.exists():
            print(f"Found frontend at: {p}")
            return p
    
    print("Frontend not found in any expected location")
    return None

FRONTEND_PATH = get_frontend_path()

# Apply configuration on startup
@app.on_event("startup")
async def startup_event():
    if USE_PG:
        try:
            run_migrations()
        except Exception as e:
            print(f"Avertissement migrations: {e}")
    apply_config_to_env()
    if FRONTEND_PATH:
        print(f"Frontend path: {FRONTEND_PATH}")
    else:
        print("Frontend not found - API-only mode")


# ===== Request/Response Models =====

class CreateConversationRequest(BaseModel):
    """Request to create a new conversation."""
    pass


class SendMessageRequest(BaseModel):
    """Request to send a message in a conversation."""
    content: str
    include_documents: Optional[bool] = True
    document_ids: Optional[List[str]] = None
    advanced: Optional[Dict[str, Any]] = None


class ConversationMetadata(BaseModel):
    """Conversation metadata for list view."""
    id: str
    created_at: str
    title: str
    message_count: int


class Conversation(BaseModel):
    """Full conversation with all messages."""
    id: str
    created_at: str
    title: str
    messages: List[Dict[str, Any]]


class ConfigUpdateRequest(BaseModel):
    """Request to update configuration."""
    openrouter_api_key: Optional[str] = None
    council_models: Optional[List[str]] = None
    chairman_model: Optional[str] = None
    lm_studio_urls: Optional[Dict[str, str]] = None
    backend_port: Optional[int] = None
    frontend_port: Optional[int] = None
    auto_credit_reminder: Optional[bool] = None
    credit_reminder_threshold: Optional[float] = None
    document_settings: Optional[Dict[str, Any]] = None
    storage_location: Optional[str] = None
    theme: Optional[str] = None


class ValidateKeyRequest(BaseModel):
    """Request to validate an API key."""
    api_key: str


class CustomModelRequest(BaseModel):
    """Request to add a custom model."""
    model_id: str
    model_name: str
    provider: str


class TestLmStudioRequest(BaseModel):
    """Request to test LM Studio connection."""
    url: str
    model_name: Optional[str] = None


class ToggleDocumentRequest(BaseModel):
    """Request to toggle document active status."""
    is_active: bool


# ===== Health Check =====

@app.get("/api/health")
async def health_check():
    """Health check endpoint."""
    config = load_config()
    has_key = bool(config.get("openrouter_api_key"))
    # Also consider configured if LM Studio URLs or advanced config is set
    has_lm_studio = bool(config.get("lm_studio_urls")) or bool(config.get("advanced_config"))
    return {
        "status": "ok", 
        "service": "LLM Council API",
        "configured": has_key or has_lm_studio,
        "version": "2.0.0"
    }


# ===== Configuration Endpoints =====

@app.get("/api/config")
async def get_configuration(user: Dict = Depends(get_current_user)):
    """Get current configuration (API key masked)."""
    return get_config()


@app.put("/api/config")
async def update_configuration(request: ConfigUpdateRequest,
                               admin: Dict = Depends(get_current_admin)):
    """Update configuration."""
    updates = request.model_dump(exclude_none=True)
    updated_config = update_config(updates)
    apply_config_to_env()
    return updated_config


@app.post("/api/config/validate-key")
async def validate_openrouter_key(request: ValidateKeyRequest,
                                  admin: Dict = Depends(get_current_admin)):
    """Validate an OpenRouter API key."""
    result = await validate_api_key(request.api_key)
    return result


@app.get("/api/models/available")
async def get_models(user: Dict = Depends(get_current_user)):
    """Get list of available models."""
    return {"models": get_available_models()}


@app.post("/api/models/custom")
async def add_custom_model_endpoint(request: CustomModelRequest,
                                    admin: Dict = Depends(get_current_admin)):
    """Add a custom model."""
    model = add_custom_model(request.model_id, request.model_name, request.provider)
    return {"model": model}


@app.post("/api/lm-studio/test")
async def test_lm_studio_endpoint(request: TestLmStudioRequest,
                                  admin: Dict = Depends(get_current_admin)):
    """Test connection to an LM Studio server."""
    result = await test_lm_studio_connection(request.url, request.model_name)
    return result


@app.get("/api/lm-studio/urls")
async def get_lm_studio_urls_endpoint(admin: Dict = Depends(get_current_admin)):
    """Get all configured LM Studio URLs."""
    return {"urls": get_lm_studio_urls()}


# ===== Advanced Config Endpoints =====

class AdvancedConfigRequest(BaseModel):
    """Request body for saving advanced config."""
    mode: Optional[str] = None
    openrouter: Optional[Dict[str, Any]] = None
    models: Optional[Dict[str, Any]] = None
    chairman: Optional[Dict[str, Any]] = None
    throttle: Optional[Dict[str, Any]] = None


@app.get("/api/config/advanced")
async def get_advanced_config_endpoint(user: Dict = Depends(get_current_user)):
    """Get advanced LLM configuration."""
    return get_advanced_config()


@app.post("/api/config/advanced")
async def save_advanced_config_endpoint(request: AdvancedConfigRequest,
                                        admin: Dict = Depends(get_current_admin)):
    """Save advanced LLM configuration."""
    config_data = request.model_dump(exclude_none=True)
    saved_config = save_advanced_config(config_data)
    return saved_config


# ===== Document Endpoints =====

@app.get("/api/documents")
async def get_documents(user: Dict = Depends(get_current_user)):
    """List the current user's uploaded documents."""
    return {"documents": list_documents(user_id=user["id"])}


@app.post("/api/documents/upload")
async def upload_document(file: UploadFile = File(...),
                          user: Dict = Depends(get_current_user)):
    """Upload a document for processing (rattaché à l'utilisateur)."""
    try:
        content = await file.read()
        result = await process_uploaded_file(
            content, 
            file.filename or "unnamed",
            file.content_type,
            user_id=user["id"]
        )
        return {"success": True, "document": result}
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error processing file: {str(e)}")


@app.get("/api/documents/{doc_id}")
async def get_document_details(doc_id: str, user: Dict = Depends(get_current_user)):
    """Get document details and content."""
    doc = get_document(doc_id, user_id=user["id"])
    if doc is None:
        raise HTTPException(status_code=404, detail="Document not found")
    
    return {
        "id": doc["id"],
        "filename": doc["filename"],
        "extension": doc["extension"],
        "size": doc["size"],
        "uploaded_at": doc["uploaded_at"],
        "chunk_count": doc.get("chunk_count", 1),
        "text_length": doc.get("text_length", 0),
        "is_active": doc.get("is_active", True),
        "extracted_text": doc.get("extracted_text", "")
    }


@app.delete("/api/documents/{doc_id}")
async def delete_document_endpoint(doc_id: str, user: Dict = Depends(get_current_user)):
    """Delete a document."""
    success = delete_document(doc_id, user_id=user["id"])
    if not success:
        raise HTTPException(status_code=404, detail="Document not found")
    return {"success": True}


@app.patch("/api/documents/{doc_id}/toggle")
async def toggle_document(doc_id: str, request: ToggleDocumentRequest,
                          user: Dict = Depends(get_current_user)):
    """Toggle document active status."""
    success = toggle_document_active(doc_id, request.is_active, user_id=user["id"])
    if not success:
        raise HTTPException(status_code=404, detail="Document not found")
    return {"success": True, "is_active": request.is_active}


@app.get("/api/documents/supported-types")
async def get_supported_types():
    """Get list of supported file types."""
    return {"supported_extensions": list(SUPPORTED_EXTENSIONS.keys())}


@app.get("/api/documents/{doc_id}/status")
async def get_document_status(doc_id: str, user: Dict = Depends(get_current_user)):
    """Get the processing status of a document."""
    doc = get_document(doc_id, user_id=user["id"])
    if doc is None:
        raise HTTPException(status_code=404, detail="Document not found")
    
    # Build status response
    status_info = {
        "id": doc["id"],
        "filename": doc["filename"],
        "status": "completed",  # Once document is in registry, processing is done
        "is_vision_image": doc.get("is_vision_image", False),
        "text_length": doc.get("text_length", 0),
        "chunk_count": doc.get("chunk_count", 1),
        "is_active": doc.get("is_active", True),
    }
    
    # Add image metadata if available
    extraction_meta = doc.get("extraction_metadata", {})
    if extraction_meta:
        status_info["extraction_details"] = {
            "width": extraction_meta.get("width"),
            "height": extraction_meta.get("height"),
            "format": extraction_meta.get("format"),
            "type": extraction_meta.get("type"),
        }
    
    return status_info


# ===== Conversation Endpoints =====

@app.get("/api/conversations", response_model=List[ConversationMetadata])
async def list_conversations(user: Dict = Depends(get_current_user)):
    """List the current user's conversations (metadata only)."""
    return storage.list_conversations(user_id=user["id"])


@app.post("/api/conversations", response_model=Conversation)
async def create_conversation(request: CreateConversationRequest,
                              user: Dict = Depends(get_current_user)):
    """Create a new conversation owned by the current user."""
    conversation_id = str(uuid.uuid4())
    conversation = storage.create_conversation(conversation_id, user_id=user["id"])
    return conversation


def _get_owned_conversation(conversation_id: str, user: Dict):
    """Charge une conversation en vérifiant la propriété (admins : accès total).
    Les conversations pré-v9 sans user_id ne sont accessibles qu'aux admins."""
    conversation = storage.get_conversation(conversation_id)
    if conversation is None:
        raise HTTPException(status_code=404, detail="Conversation not found")
    owner = conversation.get("user_id")
    if user["role"] != "admin" and owner != user["id"]:
        # 404 (et non 403) pour ne pas révéler l'existence d'une conversation d'autrui
        raise HTTPException(status_code=404, detail="Conversation not found")
    return conversation


@app.get("/api/conversations/{conversation_id}", response_model=Conversation)
async def get_conversation(conversation_id: str, user: Dict = Depends(get_current_user)):
    """Get a specific conversation with all its messages (propriétaire uniquement)."""
    return _get_owned_conversation(conversation_id, user)


@app.delete("/api/conversations/{conversation_id}")
async def delete_conversation(conversation_id: str, user: Dict = Depends(get_current_user)):
    """Delete a conversation (propriétaire uniquement)."""
    _get_owned_conversation(conversation_id, user)
    success = storage.delete_conversation(conversation_id)
    if not success:
        raise HTTPException(status_code=404, detail="Conversation not found")
    return {"success": True}


@app.post("/api/conversations/{conversation_id}/message")
async def send_message(conversation_id: str, request: SendMessageRequest,
                       user: Dict = Depends(get_current_user)):
    """
    Send a message and run the 3-stage council process (mode synchrone).
    v9 : débit atomique avant exécution, remboursement automatique si le
    pipeline échoue après débit.
    """
    advanced = request.advanced if user.get("role") == "admin" else None

    if requires_openrouter_key(advanced) and not get_api_key():
        raise HTTPException(
            status_code=400, 
            detail="OpenRouter API key not configured. Please go to Settings to add your API key."
        )
    
    conversation = _get_owned_conversation(conversation_id, user)

    is_first_message = len(conversation["messages"]) == 0

    # Build query with document context if requested (documents de l'utilisateur)
    query_content = request.content
    vision_images = []
    
    if request.include_documents:
        doc_context = get_active_documents_context(user_id=user["id"])
        if doc_context:
            query_content = f"""I have uploaded the following documents for reference:

{doc_context}

---

My question: {request.content}"""
        
        vision_images = get_active_vision_images(user_id=user["id"])
        if vision_images:
            image_note = f"\n\n[Note: {len(vision_images)} image(s) attached for visual analysis]"
            query_content += image_note

    # ===== Débit atomique AVANT exécution =====
    cost = credits_svc.get_request_cost(has_images=bool(vision_images))
    try:
        credits_svc.debit(user["id"], cost, conversation_id=conversation_id)
    except credits_svc.InsufficientCredits as e:
        raise HTTPException(
            status_code=402,
            detail={"error": "insufficient_credits", "required": e.required, "balance": e.balance},
        )

    # Add user message
    storage.add_user_message(conversation_id, request.content)

    try:
        # If this is the first message, generate a title
        if is_first_message:
            title = await generate_conversation_title(request.content, advanced_config=advanced)
            storage.update_conversation_title(conversation_id, title)

        # Run the 3-stage council process
        stage1_results, stage2_results, stage3_result, metadata = await run_full_council(
            query_content,
            vision_images=vision_images if vision_images else None,
            advanced_config=advanced
        )
    except Exception as e:
        # Remboursement automatique : échec du pipeline après débit.
        try:
            credits_svc.refund(user["id"], cost, conversation_id,
                               note=f"Échec du pipeline : {str(e)[:200]}")
        except Exception as refund_err:
            print(f"ERREUR remboursement {user['id']} ({cost} cr): {refund_err}")
        raise HTTPException(status_code=502, detail=f"Le council a échoué : {e}")

    # Add assistant message with all stages
    storage.add_assistant_message(
        conversation_id,
        stage1_results,
        stage2_results,
        stage3_result
    )

    # Return the complete response with metadata
    return {
        "stage1": stage1_results,
        "stage2": stage2_results,
        "stage3": stage3_result,
        "metadata": metadata
    }


def _ensure_run_started(conversation_id: str, request: SendMessageRequest, user: Dict):
    """Start the detached council run for a conversation (idempotent).

    v9 — c'est ICI (et uniquement ici) que le débit de crédits a lieu :
    les trois points d'entrée (/message, /message/stream, /run) convergent
    tous vers cette fonction, donc aucun chemin gratuit n'existe.
    """
    # Les réglages avancés par requête (choix de modèles, LM Studio...) sont
    # réservés aux admins : un utilisateur ne peut pas changer les modèles
    # facturés ni détourner le pipeline. Pour les autres, config globale.
    advanced = request.advanced if user.get("role") == "admin" else None

    if requires_openrouter_key(advanced) and not get_api_key():
        raise HTTPException(
            status_code=400,
            detail="OpenRouter API key not configured. Please go to Settings to add your API key."
        )

    conversation = _get_owned_conversation(conversation_id, user)

    # If a run is already in progress for this conversation, don't start another.
    if conversation_id in _run_hub:
        return

    is_first_message = len(conversation["messages"]) == 0

    # Build query with document context if requested (documents de l'utilisateur)
    query_content = request.content
    vision_images = []
    if request.include_documents:
        doc_context = get_active_documents_context(user_id=user["id"])
        if doc_context:
            query_content = f"""I have uploaded the following documents for reference:

{doc_context}

---

My question: {request.content}"""
        vision_images = get_active_vision_images(user_id=user["id"])
        if vision_images:
            query_content += f"\n\n[Note: {len(vision_images)} image(s) attached for visual analysis]"

    # ===== Débit atomique AVANT tout lancement =====
    cost = credits_svc.get_request_cost(has_images=bool(vision_images))
    try:
        credits_svc.debit(user["id"], cost, conversation_id=conversation_id)
    except credits_svc.InsufficientCredits as e:
        raise HTTPException(
            status_code=402,
            detail={"error": "insufficient_credits", "required": e.required, "balance": e.balance},
        )

    # Persist the user message and a 'running' assistant placeholder.
    storage.add_user_message(conversation_id, request.content)
    storage.add_running_assistant_message(conversation_id)

    # Create the hub and launch the detached task.
    _run_hub[conversation_id] = {"events": [], "subscribers": set()}
    task = asyncio.create_task(
        _run_council_task(
            conversation_id,
            query_content,
            vision_images if vision_images else None,
            advanced,
            is_first_message,
            request.content,
            user_id=user["id"],
            debited_cost=cost,
        )
    )
    _run_hub[conversation_id]["task"] = task  # keep a reference


@app.post("/api/conversations/{conversation_id}/run")
async def start_run(conversation_id: str, request: SendMessageRequest,
                    user: Dict = Depends(get_current_user)):
    """
    Start the 3-stage council as a DETACHED background task and return immediately.

    Progress is persisted incrementally; the frontend polls
    GET /api/conversations/{id} to display each stage as it completes. This is
    robust to page refreshes AND to SSE buffering on platforms like Heroku.
    """
    _ensure_run_started(conversation_id, request, user)
    return {"status": "started"}


@app.post("/api/conversations/{conversation_id}/message/stream")
async def send_message_stream(conversation_id: str, request: SendMessageRequest,
                              user: Dict = Depends(get_current_user)):
    """Start the run (detached) and stream live SSE events (kept for compatibility)."""
    _ensure_run_started(conversation_id, request, user)
    return StreamingResponse(
        _stream_from_hub(conversation_id),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no",
        },
    )


@app.get("/api/conversations/{conversation_id}/stream")
async def resume_message_stream(conversation_id: str,
                                user: Dict = Depends(get_current_user)):
    """Reconnect to an in-progress council run (SSE; kept for compatibility)."""
    _get_owned_conversation(conversation_id, user)
    return StreamingResponse(
        _stream_from_hub(conversation_id),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no",
        },
    )


# ===== Static File Serving for Frontend =====

# Mount static files if frontend exists
if FRONTEND_PATH and FRONTEND_PATH.exists():
    # Serve static assets (JS, CSS, images) if the assets directory exists
    assets_path = FRONTEND_PATH / "assets"
    if assets_path.exists():
        app.mount("/assets", StaticFiles(directory=str(assets_path)), name="assets")
    
    # Serve index.html for the root and any non-API routes (SPA routing)
    @app.get("/", response_class=HTMLResponse)
    async def serve_frontend_root():
        """Serve the frontend application."""
        index_path = FRONTEND_PATH / "index.html"
        if index_path.exists():
            return FileResponse(str(index_path), media_type="text/html")
        return HTMLResponse(content="<h1>LLM Council API</h1><p>Frontend not found. API is running at /api/</p>")
    
    # Catch-all for SPA routing - serve index.html for non-API routes
    @app.get("/{full_path:path}")
    async def serve_frontend_spa(full_path: str):
        """Serve frontend for SPA routing."""
        # Don't serve index.html for API routes
        if full_path.startswith("api/"):
            raise HTTPException(status_code=404, detail="Not found")
        
        # Try to serve the exact file first
        file_path = FRONTEND_PATH / full_path
        if file_path.exists() and file_path.is_file():
            return FileResponse(str(file_path))
        
        # Otherwise serve index.html for SPA routing
        index_path = FRONTEND_PATH / "index.html"
        if index_path.exists():
            return FileResponse(str(index_path), media_type="text/html")
        
        raise HTTPException(status_code=404, detail="Not found")


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8001)
