"""Authentification v9 — Google OAuth 2.0 (SSO uniquement) + session JWT.

Flux : /api/auth/login -> Google -> /api/auth/callback -> cookie httpOnly JWT.
Pas de mots de passe, pas de table credentials. Le premier admin est créé via
la variable d'environnement ADMIN_EMAILS (liste séparée par des virgules) :
à chaque login, si l'email y figure, le rôle passe à 'admin'.
"""

import os
import time
import threading
from collections import defaultdict, deque
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, Optional

import httpx
import jwt
from fastapi import APIRouter, Depends, HTTPException, Request, Response
from fastapi.responses import RedirectResponse

try:
    from .db import pg
except ImportError:
    from db import pg

router = APIRouter(prefix="/api/auth", tags=["auth"])

GOOGLE_CLIENT_ID = os.getenv("GOOGLE_CLIENT_ID", "")
GOOGLE_CLIENT_SECRET = os.getenv("GOOGLE_CLIENT_SECRET", "")
JWT_SECRET = os.getenv("JWT_SECRET", "")
JWT_ALG = "HS256"
JWT_TTL_DAYS = 7
COOKIE_NAME = "llmc_session"
ADMIN_EMAILS = {
    e.strip().lower() for e in os.getenv("ADMIN_EMAILS", "").split(",") if e.strip()
}
# En prod (Heroku), Secure=True. En dev local http, mettre COOKIE_SECURE=false.
COOKIE_SECURE = os.getenv("COOKIE_SECURE", "true").lower() != "false"

GOOGLE_AUTH_URL = "https://accounts.google.com/o/oauth2/v2/auth"
GOOGLE_TOKEN_URL = "https://oauth2.googleapis.com/token"
GOOGLE_USERINFO_URL = "https://openidconnect.googleapis.com/v1/userinfo"


def _require_config():
    if not (GOOGLE_CLIENT_ID and GOOGLE_CLIENT_SECRET and JWT_SECRET):
        raise HTTPException(
            status_code=503,
            detail="Authentification non configurée (GOOGLE_CLIENT_ID / "
                   "GOOGLE_CLIENT_SECRET / JWT_SECRET manquants).",
        )


def _redirect_uri(request: Request) -> str:
    """URI de callback. APP_BASE_URL prime (fiable derrière le proxy Heroku)."""
    base = os.getenv("APP_BASE_URL")
    if base:
        return base.rstrip("/") + "/api/auth/callback"
    proto = request.headers.get("x-forwarded-proto", request.url.scheme)
    host = request.headers.get("x-forwarded-host", request.headers.get("host", ""))
    return f"{proto}://{host}/api/auth/callback"


# ===================== Rate limiting (mémoire, single dyno) =====================

_rl_hits: Dict[str, deque] = defaultdict(deque)
_rl_lock = threading.Lock()


def rate_limit(scope: str, limit: int = 10, window: float = 60.0):
    """Fenêtre glissante par IP. Suffisant pour un single dyno web."""
    def dep(request: Request):
        ip = request.headers.get("x-forwarded-for", request.client.host if request.client else "?")
        ip = ip.split(",")[0].strip()
        key = f"{scope}:{ip}"
        now = time.monotonic()
        with _rl_lock:
            q = _rl_hits[key]
            while q and now - q[0] > window:
                q.popleft()
            if len(q) >= limit:
                raise HTTPException(status_code=429, detail="Trop de requêtes, réessayez dans une minute.")
            q.append(now)
    return dep


# ===================== JWT =====================

def _issue_jwt(user_id: str, email: str, role: str) -> str:
    now = datetime.now(timezone.utc)
    return jwt.encode(
        {
            "sub": user_id,
            "email": email,
            "role": role,
            "iat": now,
            "exp": now + timedelta(days=JWT_TTL_DAYS),
        },
        JWT_SECRET,
        algorithm=JWT_ALG,
    )


def _set_session_cookie(response: Response, token: str):
    response.set_cookie(
        COOKIE_NAME,
        token,
        max_age=JWT_TTL_DAYS * 86400,
        httponly=True,
        secure=COOKIE_SECURE,
        samesite="lax",
        path="/",
    )


# ===================== Accès utilisateurs =====================

def _row_to_user(row) -> Dict[str, Any]:
    return {
        "id": str(row[0]),
        "google_sub": row[1],
        "email": row[2],
        "display_name": row[3],
        "avatar_url": row[4],
        "role": row[5],
        "credits": row[6],
        "is_active": row[7],
        "created_at": row[8].isoformat() if row[8] else None,
        "last_login_at": row[9].isoformat() if row[9] else None,
    }


_USER_COLS = ("id, google_sub, email, display_name, avatar_url, role, "
              "credits, is_active, created_at, last_login_at")


def get_user_by_id(user_id: str) -> Optional[Dict[str, Any]]:
    with pg() as conn:
        with conn.cursor() as cur:
            cur.execute(f"SELECT {_USER_COLS} FROM users WHERE id = %s", (user_id,))
            row = cur.fetchone()
    return _row_to_user(row) if row else None


def upsert_google_user(sub: str, email: str, name: str, picture: str) -> Dict[str, Any]:
    email = (email or "").lower()
    role_forced = "admin" if email in ADMIN_EMAILS else None
    with pg() as conn:
        with conn.cursor() as cur:
            cur.execute(
                f"""
                INSERT INTO users (google_sub, email, display_name, avatar_url,
                                   role, last_login_at)
                VALUES (%s, %s, %s, %s, COALESCE(%s, 'user'), now())
                ON CONFLICT (google_sub) DO UPDATE SET
                    email = EXCLUDED.email,
                    display_name = EXCLUDED.display_name,
                    avatar_url = EXCLUDED.avatar_url,
                    role = COALESCE(%s, users.role),
                    last_login_at = now()
                RETURNING {_USER_COLS}
                """,
                (sub, email, name, picture, role_forced, role_forced),
            )
            row = cur.fetchone()
    return _row_to_user(row)


# ===================== Dépendances FastAPI =====================

def get_current_user(request: Request) -> Dict[str, Any]:
    """Lit le JWT du cookie, vérifie la signature, recharge l'utilisateur en base
    (source de vérité pour role / credits / is_active)."""
    _require_config()
    token = request.cookies.get(COOKIE_NAME)
    if not token:
        raise HTTPException(status_code=401, detail="Non authentifié")
    try:
        payload = jwt.decode(token, JWT_SECRET, algorithms=[JWT_ALG])
    except jwt.PyJWTError:
        raise HTTPException(status_code=401, detail="Session invalide ou expirée")
    user = get_user_by_id(payload["sub"])
    if user is None:
        raise HTTPException(status_code=401, detail="Utilisateur inconnu")
    if not user["is_active"]:
        raise HTTPException(status_code=403, detail="Compte désactivé")
    return user


def get_current_admin(user: Dict[str, Any] = Depends(get_current_user)) -> Dict[str, Any]:
    if user["role"] != "admin":
        raise HTTPException(status_code=403, detail="Accès administrateur requis")
    return user


# ===================== Endpoints =====================

@router.get("/login", dependencies=[Depends(rate_limit("auth", 10))])
async def login(request: Request):
    _require_config()
    state = jwt.encode(
        {"exp": datetime.now(timezone.utc) + timedelta(minutes=10), "purpose": "oauth_state"},
        JWT_SECRET, algorithm=JWT_ALG,
    )
    params = httpx.QueryParams({
        "client_id": GOOGLE_CLIENT_ID,
        "redirect_uri": _redirect_uri(request),
        "response_type": "code",
        "scope": "openid email profile",
        "state": state,
        "prompt": "select_account",
    })
    return RedirectResponse(f"{GOOGLE_AUTH_URL}?{params}")


@router.get("/callback", dependencies=[Depends(rate_limit("auth", 10))])
async def callback(request: Request, code: str = "", state: str = "", error: str = ""):
    _require_config()
    if error or not code:
        return RedirectResponse("/login?error=google_denied")
    try:
        jwt.decode(state, JWT_SECRET, algorithms=[JWT_ALG])
    except jwt.PyJWTError:
        raise HTTPException(status_code=400, detail="State OAuth invalide")

    async with httpx.AsyncClient(timeout=15) as client:
        token_resp = await client.post(GOOGLE_TOKEN_URL, data={
            "code": code,
            "client_id": GOOGLE_CLIENT_ID,
            "client_secret": GOOGLE_CLIENT_SECRET,
            "redirect_uri": _redirect_uri(request),
            "grant_type": "authorization_code",
        })
        if token_resp.status_code != 200:
            raise HTTPException(status_code=502, detail="Échec de l'échange de code Google")
        access_token = token_resp.json().get("access_token")
        info_resp = await client.get(
            GOOGLE_USERINFO_URL, headers={"Authorization": f"Bearer {access_token}"}
        )
        if info_resp.status_code != 200:
            raise HTTPException(status_code=502, detail="Échec userinfo Google")
        info = info_resp.json()

    user = upsert_google_user(
        sub=info["sub"],
        email=info.get("email", ""),
        name=info.get("name", ""),
        picture=info.get("picture", ""),
    )
    if not user["is_active"]:
        return RedirectResponse("/login?error=account_disabled")

    token = _issue_jwt(user["id"], user["email"], user["role"])
    response = RedirectResponse("/")
    _set_session_cookie(response, token)
    return response


@router.post("/logout")
async def logout():
    response = Response(status_code=204)
    response.delete_cookie(COOKIE_NAME, path="/")
    return response


@router.get("/me")
async def me(user: Dict[str, Any] = Depends(get_current_user)):
    return {
        "id": user["id"],
        "email": user["email"],
        "display_name": user["display_name"],
        "avatar_url": user["avatar_url"],
        "role": user["role"],
        "credits": user["credits"],
    }
