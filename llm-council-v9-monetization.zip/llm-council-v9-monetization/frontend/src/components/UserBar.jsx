import { useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../AuthContext';
import '../pages/v9.css';

/**
 * Barre utilisateur fixée en haut à droite : avatar, nom, solde de crédits
 * en temps réel (rafraîchi toutes les 30 s et après chaque requête council),
 * bouton d'achat, lien admin, déconnexion.
 */
export default function UserBar() {
  const { user, refresh, logout } = useAuth();

  useEffect(() => {
    const t = setInterval(() => refresh(), 30000);
    return () => clearInterval(t);
  }, [refresh]);

  if (!user) return null;

  return (
    <div className="v9-userbar">
      {user.avatar_url && <img src={user.avatar_url} alt="" referrerPolicy="no-referrer" />}
      <span>{user.display_name || user.email}</span>
      <span className="v9-credits">{user.credits} cr</span>
      <Link to="/credits" className="v9-buy">Acheter des crédits</Link>
      {user.role === 'admin' && <Link to="/admin">Admin</Link>}
      <button onClick={logout} title="Se déconnecter">Déconnexion</button>
    </div>
  );
}
