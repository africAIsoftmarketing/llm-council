import { useCallback, useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { PayPalScriptProvider, PayPalButtons } from '@paypal/react-paypal-js';
import { useAuth } from '../AuthContext';
import { paymentsApi } from '../apiV9';
import './v9.css';

const KIND_LABELS = {
  purchase: 'Achat',
  usage: 'Requête',
  admin_grant: 'Ajustement admin',
  refund: 'Remboursement',
};

function PackCard({ pack, onCredited, onError }) {
  return (
    <div className="v9-pack-card">
      <h3>{pack.name}</h3>
      <div className="v9-pack-price">{Number(pack.price_cad).toFixed(2)} $ CAD</div>
      <div className="v9-pack-credits">{pack.credits} crédits</div>
      <PayPalButtons
        style={{ layout: 'horizontal', tagline: false, height: 40 }}
        forceReRender={[pack.id]}
        createOrder={async () => {
          const { order_id } = await paymentsApi.createOrder(pack.id);
          return order_id;
        }}
        onApprove={async (data) => {
          try {
            const result = await paymentsApi.captureOrder(data.orderID);
            onCredited(result);
          } catch (e) {
            onError(e.message || 'Échec de la capture du paiement');
          }
        }}
        onError={() => onError('Erreur PayPal — aucun montant débité')}
      />
    </div>
  );
}

export default function Credits() {
  const { user, refresh } = useAuth();
  const [packs, setPacks] = useState([]);
  const [paypalCfg, setPaypalCfg] = useState(null);
  const [transactions, setTransactions] = useState([]);
  const [toast, setToast] = useState(null);

  const loadAll = useCallback(async () => {
    const [{ packs: p }, cfg, { transactions: tx }] = await Promise.all([
      paymentsApi.packs(), paymentsApi.config(), paymentsApi.transactions(),
    ]);
    setPacks(p); setPaypalCfg(cfg); setTransactions(tx);
  }, []);

  useEffect(() => { loadAll().catch(() => {}); }, [loadAll]);

  const showToast = (message, type = 'success') => {
    setToast({ message, type });
    setTimeout(() => setToast(null), 5000);
  };

  const handleCredited = async (result) => {
    await refresh();
    await loadAll();
    showToast(
      result.status === 'already_credited'
        ? 'Paiement déjà comptabilisé — votre solde est à jour.'
        : `+${result.credits} crédits ! Nouveau solde : ${result.balance}.`
    );
  };

  return (
    <div className="v9-page">
      <header className="v9-page-header">
        <Link to="/" className="v9-back-link">← Retour au council</Link>
        <h1>Acheter des crédits</h1>
        <div className="v9-balance-pill">Solde actuel : <strong>{user?.credits ?? 0}</strong> crédits</div>
      </header>

      {toast && <div className={`v9-alert v9-alert-${toast.type === 'success' ? 'success' : 'error'}`}>{toast.message}</div>}

      {paypalCfg?.mode === 'sandbox' && (
        <div className="v9-alert v9-alert-info">
          Mode sandbox PayPal — aucun paiement réel ne sera effectué.
        </div>
      )}

      {paypalCfg?.client_id ? (
        <PayPalScriptProvider options={{
          clientId: paypalCfg.client_id,
          currency: paypalCfg.currency || 'CAD',
          intent: 'capture',
        }}>
          <div className="v9-packs-grid">
            {packs.map((pack) => (
              <PackCard key={pack.id} pack={pack}
                        onCredited={handleCredited}
                        onError={(m) => showToast(m, 'error')} />
            ))}
          </div>
        </PayPalScriptProvider>
      ) : (
        <div className="v9-alert v9-alert-error">PayPal n'est pas configuré sur ce déploiement.</div>
      )}

      <section className="v9-history">
        <h2>Historique des transactions</h2>
        {transactions.length === 0 ? (
          <p className="v9-muted">Aucune transaction pour l'instant.</p>
        ) : (
          <table className="v9-table">
            <thead>
              <tr><th>Date</th><th>Type</th><th>Crédits</th><th>Montant</th><th>Solde après</th></tr>
            </thead>
            <tbody>
              {transactions.map((t, i) => (
                <tr key={i}>
                  <td>{new Date(t.created_at).toLocaleString('fr-CA')}</td>
                  <td>{KIND_LABELS[t.kind] || t.kind}</td>
                  <td className={t.amount > 0 ? 'v9-pos' : 'v9-neg'}>
                    {t.amount > 0 ? `+${t.amount}` : t.amount}
                  </td>
                  <td>{t.amount_cad != null ? `${Number(t.amount_cad).toFixed(2)} $` : '—'}</td>
                  <td>{t.balance_after}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </section>
    </div>
  );
}
