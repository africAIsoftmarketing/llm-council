import { useCallback, useEffect, useState } from 'react';
import { Link, Navigate } from 'react-router-dom';
import { useAuth } from '../AuthContext';
import { adminApi } from '../apiV9';
import './v9.css';

const TABS = [
  { id: 'models', label: 'Modèles' },
  { id: 'users', label: 'Utilisateurs' },
  { id: 'pricing', label: 'Tarification' },
  { id: 'stats', label: 'Statistiques' },
];

export default function Admin() {
  const { user, loading } = useAuth();
  const [tab, setTab] = useState('models');
  const [toast, setToast] = useState(null);

  const showToast = (message, type = 'success') => {
    setToast({ message, type });
    setTimeout(() => setToast(null), 5000);
  };

  if (loading) return <div className="v9-page"><p className="v9-muted">Chargement…</p></div>;
  if (!user || user.role !== 'admin') return <Navigate to="/" replace />;

  return (
    <div className="v9-page v9-admin">
      <header className="v9-page-header">
        <Link to="/" className="v9-back-link">← Retour au council</Link>
        <h1>Administration</h1>
      </header>
      {toast && <div className={`v9-alert v9-alert-${toast.type === 'success' ? 'success' : 'error'}`}>{toast.message}</div>}
      <nav className="v9-tabs">
        {TABS.map((t) => (
          <button key={t.id} className={tab === t.id ? 'active' : ''} onClick={() => setTab(t.id)}>
            {t.label}
          </button>
        ))}
      </nav>
      {tab === 'models' && <ModelsTab showToast={showToast} />}
      {tab === 'users' && <UsersTab showToast={showToast} />}
      {tab === 'pricing' && <PricingTab showToast={showToast} />}
      {tab === 'stats' && <StatsTab />}
    </div>
  );
}

/* ===================== Modèles ===================== */

function ModelsTab({ showToast }) {
  const [models, setModels] = useState([]);
  const [chairman, setChairman] = useState('');
  const [newModel, setNewModel] = useState('');
  const [busy, setBusy] = useState(false);

  const load = useCallback(async () => {
    const data = await adminApi.models();
    setModels(data.council_models || []);
    setChairman(data.chairman_model || '');
  }, []);
  useEffect(() => { load().catch(() => {}); }, [load]);

  const addModel = async () => {
    if (!newModel.trim()) return;
    setBusy(true);
    try {
      await adminApi.addModel(newModel.trim());
      setNewModel('');
      await load();
      showToast('Modèle validé auprès d\'OpenRouter et ajouté.');
    } catch (e) {
      showToast(e.message, 'error');
    } finally {
      setBusy(false);
    }
  };

  const removeModel = async (id) => {
    if (!window.confirm(`Retirer ${id} du council ?`)) return;
    try {
      await adminApi.removeModel(id);
      await load();
      showToast('Modèle retiré.');
    } catch (e) {
      showToast(e.message, 'error');
    }
  };

  const setChair = async (id) => {
    try {
      await adminApi.setChairman(id);
      setChairman(id);
      showToast('Chairman mis à jour.');
    } catch (e) {
      showToast(e.message, 'error');
    }
  };

  return (
    <section>
      <h2>Membres du council</h2>
      <p className="v9-muted">Les changements prennent effet immédiatement, sans redéploiement.</p>
      <ul className="v9-model-list">
        {models.map((m) => (
          <li key={m}>
            <span className="v9-model-id">{m}</span>
            {chairman === m && <span className="v9-chip">Chairman</span>}
            <span className="v9-row-actions">
              {chairman !== m && (
                <button className="v9-btn-sm" onClick={() => setChair(m)}>Définir chairman</button>
              )}
              <button className="v9-btn-sm v9-btn-danger" onClick={() => removeModel(m)}
                      disabled={models.length <= 2} title={models.length <= 2 ? 'Minimum 2 modèles' : ''}>
                Supprimer
              </button>
            </span>
          </li>
        ))}
      </ul>
      <div className="v9-inline-form">
        <input value={newModel} onChange={(e) => setNewModel(e.target.value)}
               placeholder="ex. anthropic/claude-sonnet-4-5"
               onKeyDown={(e) => e.key === 'Enter' && addModel()} />
        <button className="v9-btn" onClick={addModel} disabled={busy}>
          {busy ? 'Validation…' : 'Ajouter (validé via OpenRouter)'}
        </button>
      </div>
    </section>
  );
}

/* ===================== Utilisateurs ===================== */

function UsersTab({ showToast }) {
  const [data, setData] = useState({ users: [], total: 0, page: 1 });
  const [search, setSearch] = useState('');
  const [page, setPage] = useState(1);

  const load = useCallback(async () => {
    setData(await adminApi.users(page, search));
  }, [page, search]);
  useEffect(() => { load().catch(() => {}); }, [load]);

  const adjust = async (u) => {
    const raw = window.prompt(`Ajuster les crédits de ${u.email} (ex. 50 ou -20) :`);
    if (!raw) return;
    const delta = parseInt(raw, 10);
    if (Number.isNaN(delta) || delta === 0) return showToast('Valeur invalide', 'error');
    const note = window.prompt('Motif de l\'ajustement :') || '';
    try {
      const { balance } = await adminApi.adjustCredits(u.id, delta, note);
      showToast(`Nouveau solde de ${u.email} : ${balance}`);
      await load();
    } catch (e) {
      showToast(e.message, 'error');
    }
  };

  const patch = async (u, body, label) => {
    try {
      await adminApi.patchUser(u.id, body);
      showToast(label);
      await load();
    } catch (e) {
      showToast(e.message, 'error');
    }
  };

  const pages = Math.max(1, Math.ceil(data.total / 25));

  return (
    <section>
      <div className="v9-inline-form">
        <input placeholder="Rechercher par email…" value={search}
               onChange={(e) => { setSearch(e.target.value); setPage(1); }} />
      </div>
      <table className="v9-table">
        <thead>
          <tr>
            <th>Email</th><th>Rôle</th><th>Crédits</th><th>Requêtes</th>
            <th>Dernière connexion</th><th>Statut</th><th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {data.users.map((u) => (
            <tr key={u.id} className={u.is_active ? '' : 'v9-row-disabled'}>
              <td>{u.email}</td>
              <td>{u.role === 'admin' ? <span className="v9-chip">admin</span> : 'user'}</td>
              <td>{u.credits}</td>
              <td>{u.request_count}</td>
              <td>{u.last_login_at ? new Date(u.last_login_at).toLocaleString('fr-CA') : '—'}</td>
              <td>{u.is_active ? 'Actif' : 'Désactivé'}</td>
              <td className="v9-row-actions">
                <button className="v9-btn-sm" onClick={() => adjust(u)}>± Crédits</button>
                <button className="v9-btn-sm"
                        onClick={() => patch(u, { is_active: !u.is_active },
                          u.is_active ? 'Compte désactivé.' : 'Compte réactivé.')}>
                  {u.is_active ? 'Désactiver' : 'Activer'}
                </button>
                <button className="v9-btn-sm"
                        onClick={() => patch(u, { role: u.role === 'admin' ? 'user' : 'admin' },
                          'Rôle mis à jour.')}>
                  {u.role === 'admin' ? 'Rétrograder' : 'Promouvoir admin'}
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      <div className="v9-pagination">
        <button className="v9-btn-sm" disabled={page <= 1} onClick={() => setPage(page - 1)}>←</button>
        <span>Page {page} / {pages} ({data.total} utilisateurs)</span>
        <button className="v9-btn-sm" disabled={page >= pages} onClick={() => setPage(page + 1)}>→</button>
      </div>
    </section>
  );
}

/* ===================== Tarification ===================== */

function PricingTab({ showToast }) {
  const [packs, setPacks] = useState([]);
  const [cost, setCost] = useState({ standard: 10, vision: 15 });

  const load = useCallback(async () => {
    const s = await adminApi.settings();
    setPacks(s.credit_packs || []);
    setCost(s.request_cost || { standard: 10, vision: 15 });
  }, []);
  useEffect(() => { load().catch(() => {}); }, [load]);

  const updatePack = (i, field, value) => {
    setPacks(packs.map((p, j) => (j === i ? { ...p, [field]: value } : p)));
  };

  const savePacks = async () => {
    try {
      const clean = packs.map((p) => ({
        ...p, price_cad: parseFloat(p.price_cad), credits: parseInt(p.credits, 10),
      }));
      await adminApi.putSetting('credit_packs', clean);
      showToast('Packs enregistrés — effectifs immédiatement.');
    } catch (e) {
      showToast(e.message, 'error');
    }
  };

  const saveCost = async () => {
    try {
      await adminApi.putSetting('request_cost', {
        standard: parseInt(cost.standard, 10), vision: parseInt(cost.vision, 10),
      });
      showToast('Coût par requête enregistré.');
    } catch (e) {
      showToast(e.message, 'error');
    }
  };

  return (
    <section>
      <h2>Packs de crédits</h2>
      <table className="v9-table">
        <thead><tr><th>ID</th><th>Nom</th><th>Prix (CAD)</th><th>Crédits</th></tr></thead>
        <tbody>
          {packs.map((p, i) => (
            <tr key={p.id}>
              <td>{p.id}</td>
              <td><input value={p.name} onChange={(e) => updatePack(i, 'name', e.target.value)} /></td>
              <td><input type="number" step="0.01" value={p.price_cad}
                         onChange={(e) => updatePack(i, 'price_cad', e.target.value)} /></td>
              <td><input type="number" value={p.credits}
                         onChange={(e) => updatePack(i, 'credits', e.target.value)} /></td>
            </tr>
          ))}
        </tbody>
      </table>
      <button className="v9-btn" onClick={savePacks}>Enregistrer les packs</button>

      <h2>Coût par requête</h2>
      <div className="v9-inline-form">
        <label>Standard <input type="number" value={cost.standard}
               onChange={(e) => setCost({ ...cost, standard: e.target.value })} /></label>
        <label>Vision <input type="number" value={cost.vision}
               onChange={(e) => setCost({ ...cost, vision: e.target.value })} /></label>
        <button className="v9-btn" onClick={saveCost}>Enregistrer</button>
      </div>
    </section>
  );
}

/* ===================== Statistiques ===================== */

function StatsTab() {
  const [stats, setStats] = useState(null);
  useEffect(() => { adminApi.stats().then(setStats).catch(() => {}); }, []);
  if (!stats) return <p className="v9-muted">Chargement…</p>;

  const KIND_LABELS = { purchase: 'Achat', usage: 'Requête', admin_grant: 'Admin', refund: 'Remb.' };

  return (
    <section>
      <div className="v9-stat-cards">
        <div className="v9-stat-card"><div className="v9-stat-value">{stats.revenue_cad.toFixed(2)} $</div><div>Revenus (CAD)</div></div>
        <div className="v9-stat-card"><div className="v9-stat-value">{stats.credits_consumed}</div><div>Crédits consommés</div></div>
        <div className="v9-stat-card"><div className="v9-stat-value">{stats.active_users}</div><div>Utilisateurs actifs</div></div>
        <div className="v9-stat-card"><div className="v9-stat-value">{stats.requests_7d}</div><div>Requêtes (7 j)</div></div>
        <div className="v9-stat-card"><div className="v9-stat-value">{stats.requests_30d}</div><div>Requêtes (30 j)</div></div>
      </div>
      <h2>50 dernières transactions</h2>
      <table className="v9-table">
        <thead><tr><th>Date</th><th>Utilisateur</th><th>Type</th><th>Crédits</th><th>CAD</th><th>Solde</th></tr></thead>
        <tbody>
          {stats.recent_transactions.map((t, i) => (
            <tr key={i}>
              <td>{new Date(t.created_at).toLocaleString('fr-CA')}</td>
              <td>{t.email}</td>
              <td>{KIND_LABELS[t.kind] || t.kind}</td>
              <td className={t.amount > 0 ? 'v9-pos' : 'v9-neg'}>{t.amount > 0 ? `+${t.amount}` : t.amount}</td>
              <td>{t.amount_cad != null ? Number(t.amount_cad).toFixed(2) : '—'}</td>
              <td>{t.balance_after}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </section>
  );
}
