import { useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { useAuth } from '../AuthContext';
import { authApi } from '../apiV9';
import './v9.css';

export default function Login() {
  const { user, loading } = useAuth();
  const navigate = useNavigate();
  const [params] = useSearchParams();
  const error = params.get('error');

  useEffect(() => {
    if (!loading && user) navigate('/', { replace: true });
  }, [user, loading, navigate]);

  return (
    <div className="v9-login-page">
      <div className="v9-login-card">
        <h1>LLM Council</h1>
        <p className="v9-login-tagline">
          Quatre modèles délibèrent, un président synthétise. Connectez-vous
          pour interroger le council.
        </p>
        {error === 'account_disabled' && (
          <div className="v9-alert v9-alert-error">
            Votre compte a été désactivé. Contactez l'administrateur.
          </div>
        )}
        {error === 'google_denied' && (
          <div className="v9-alert v9-alert-error">
            Connexion Google annulée ou refusée. Réessayez.
          </div>
        )}
        <a className="v9-google-btn" href={authApi.loginUrl()}>
          <svg width="18" height="18" viewBox="0 0 48 48" aria-hidden="true">
            <path fill="#EA4335" d="M24 9.5c3.5 0 6.6 1.2 9 3.5l6.7-6.7C35.6 2.5 30.2 0 24 0 14.6 0 6.5 5.4 2.6 13.3l7.8 6.1C12.3 13.4 17.7 9.5 24 9.5z"/>
            <path fill="#4285F4" d="M46.5 24.5c0-1.6-.1-3.1-.4-4.5H24v9h12.7c-.6 3-2.3 5.5-4.8 7.2l7.5 5.8c4.4-4.1 7.1-10.1 7.1-17.5z"/>
            <path fill="#FBBC05" d="M10.4 28.6c-.5-1.5-.8-3-.8-4.6s.3-3.1.8-4.6l-7.8-6.1C.9 16.5 0 20.1 0 24s.9 7.5 2.6 10.7l7.8-6.1z"/>
            <path fill="#34A853" d="M24 48c6.2 0 11.4-2 15.2-5.5l-7.5-5.8c-2.1 1.4-4.7 2.2-7.7 2.2-6.3 0-11.7-3.9-13.6-9.5l-7.8 6.1C6.5 42.6 14.6 48 24 48z"/>
          </svg>
          Se connecter avec Google
        </a>
        <p className="v9-login-footnote">
          Aucun mot de passe requis — authentification via votre compte Google.
        </p>
      </div>
    </div>
  );
}
