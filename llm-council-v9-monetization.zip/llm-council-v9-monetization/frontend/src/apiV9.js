// Client API v9 — authentification, paiements, administration.
// Toutes les requêtes portent les cookies de session (credentials: 'include').

const API_BASE = import.meta.env.VITE_BACKEND_URL || import.meta.env.REACT_APP_BACKEND_URL || '';

export class ApiError extends Error {
  constructor(status, detail) {
    super(typeof detail === 'string' ? detail : detail?.error || 'Erreur API');
    this.status = status;
    this.detail = detail;
  }
}

async function request(path, options = {}) {
  const response = await fetch(`${API_BASE}${path}`, {
    credentials: 'include',
    headers: { 'Content-Type': 'application/json', ...(options.headers || {}) },
    ...options,
  });
  if (response.status === 204) return null;
  const body = await response.json().catch(() => ({}));
  if (!response.ok) throw new ApiError(response.status, body.detail ?? body);
  return body;
}

export const authApi = {
  loginUrl: () => `${API_BASE}/api/auth/login`,
  me: () => request('/api/auth/me'),
  logout: () => request('/api/auth/logout', { method: 'POST' }),
};

export const paymentsApi = {
  config: () => request('/api/payments/config'),
  packs: () => request('/api/payments/packs'),
  transactions: () => request('/api/payments/transactions'),
  createOrder: (packId) =>
    request('/api/payments/orders', { method: 'POST', body: JSON.stringify({ pack_id: packId }) }),
  captureOrder: (orderId) =>
    request(`/api/payments/orders/${orderId}/capture`, { method: 'POST' }),
};

export const adminApi = {
  models: () => request('/api/admin/models'),
  addModel: (modelId) =>
    request('/api/admin/models', { method: 'POST', body: JSON.stringify({ model_id: modelId }) }),
  removeModel: (modelId) =>
    request(`/api/admin/models/${encodeURIComponent(modelId)}`, { method: 'DELETE' }),
  setChairman: (modelId) =>
    request('/api/admin/chairman', { method: 'PUT', body: JSON.stringify({ model_id: modelId }) }),
  users: (page = 1, search = '') =>
    request(`/api/admin/users?page=${page}&per_page=25&search=${encodeURIComponent(search)}`),
  patchUser: (userId, patch) =>
    request(`/api/admin/users/${userId}`, { method: 'PATCH', body: JSON.stringify(patch) }),
  adjustCredits: (userId, delta, note) =>
    request(`/api/admin/users/${userId}/credits`, {
      method: 'POST', body: JSON.stringify({ delta, note }),
    }),
  settings: () => request('/api/admin/settings'),
  putSetting: (key, value) =>
    request(`/api/admin/settings/${key}`, { method: 'PUT', body: JSON.stringify({ value }) }),
  stats: () => request('/api/admin/stats'),
};
