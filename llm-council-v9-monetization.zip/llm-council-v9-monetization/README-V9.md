# LLM Council v9 — Monétisation (SSO Google + crédits PayPal + Admin)

v9 transforme LLM Council en SaaS : chaque requête au council est payée en
crédits prépayés, achetés par packs via PayPal. Le pipeline de délibération
(`council.py`) est **strictement identique à v8**.

## Architecture

```
Visiteur ──> /login (Google SSO) ──> Session JWT (cookie httpOnly)
                                          │
                            Solde ≥ coût de la requête ?
                            OUI │                    │ NON (HTTP 402)
                                ▼                    ▼
                      Débit atomique          Modal « Crédits insuffisants »
                      Pipeline council        → /credits (PayPal Checkout)
                      (refund auto si échec)  → webhook/capture → crédit idempotent
```

## Nouveautés v9

| Zone | Fichier(s) | Rôle |
|------|-----------|------|
| DB partagée | `backend/db.py`, `backend/migrate.py` | Pool unique, migrations idempotentes, `app_settings` (cache 60 s) |
| Auth | `backend/auth.py` | Google OAuth 2.0, JWT cookie, `get_current_user` / `get_current_admin`, rate limiting |
| Crédits | `backend/credits.py` | Débit atomique SQL, crédit idempotent, remboursement, ajustements admin |
| Paiement | `backend/payments.py` | PayPal Orders v2 (montants relus serveur), capture vérifiée, webhook signé |
| Admin | `backend/admin.py` | Modèles (validés via OpenRouter), utilisateurs, tarification, statistiques |
| Frontend | `src/pages/*`, `src/AuthContext.jsx`, `src/apiV9.js`, `src/components/UserBar.jsx` | Login, achat de crédits, panneau admin, solde temps réel, modal 402 |

### Points d'intégrité (non négociables, implémentés)

1. **Débit atomique** : `UPDATE users SET credits = credits - coût WHERE id = … AND credits >= coût`.
   0 ligne affectée → HTTP 402. Jamais de check-then-update.
2. **Un seul point de débit** : les trois entrées (`/message`, `/message/stream`, `/run`)
   convergent vers `_ensure_run_started` — aucun chemin gratuit.
3. **Remboursement automatique** dans la tâche de fond détachée (le pipeline
   tourne hors du handler HTTP) : échec après débit → transaction `refund`.
4. **Idempotence PayPal** : index unique partiel sur `paypal_order_id` —
   capture + webhook peuvent tous deux tenter le crédit, un seul passe.
5. **Montants côté serveur** : prix des packs et coûts par requête toujours
   relus depuis `app_settings`, jamais depuis le client.
6. **Webhook signé** : vérification via l'API PayPal `verify-webhook-signature`.
7. **Isolation utilisateur** : conversations et documents filtrés par
   propriétaire (accès d'autrui → 404). Les endpoints de configuration v8
   (`PUT /api/config`, modèles custom, LM Studio…) exigent désormais le rôle admin.
8. **Réglages avancés par requête** (choix de modèles) réservés aux admins :
   un utilisateur ne peut pas changer les modèles facturés.

## Variables d'environnement

```bash
# Base (existant)
OPENROUTER_API_KEY=...
DATABASE_URL=...                    # posé automatiquement par l'addon Heroku Postgres

# Auth Google
GOOGLE_CLIENT_ID=...
GOOGLE_CLIENT_SECRET=...
JWT_SECRET=...                      # openssl rand -hex 32
ADMIN_EMAILS=cedric@africaisoft.com # séparés par des virgules
APP_BASE_URL=https://<app>.herokuapp.com

# PayPal
PAYPAL_CLIENT_ID=...
PAYPAL_CLIENT_SECRET=...
PAYPAL_MODE=sandbox                 # 'sandbox' | 'live'
PAYPAL_WEBHOOK_ID=...               # créé dans le dashboard développeur PayPal

# Optionnel
COOKIE_SECURE=true                  # 'false' uniquement en dev local http
```

## Mise en route

### 1. Base de données

```bash
heroku addons:create heroku-postgresql:essential-0
```

Les migrations tournent automatiquement en phase release
(`release: python -m backend.migrate` dans le Procfile). Elles sont
idempotentes et **adoptent** la table `conversations` v8 existante
(ajout de la colonne `user_id`, aucune donnée perdue).

### 2. Credentials Google

1. [console.cloud.google.com](https://console.cloud.google.com) → APIs & Services → OAuth consent screen (type External, scopes openid/email/profile)
2. Credentials → Create OAuth Client ID → Web application
3. Redirect URI autorisée : `https://<app>.herokuapp.com/api/auth/callback`
4. Copier client ID/secret dans les variables d'environnement

### 3. PayPal

1. [developer.paypal.com](https://developer.paypal.com) → Apps & Credentials → créer une app (sandbox)
2. Copier Client ID / Secret
3. Webhooks → ajouter `https://<app>.herokuapp.com/api/payments/webhook`,
   événement `PAYMENT.CAPTURE.COMPLETED` → copier le Webhook ID
4. Bascule en production : `PAYPAL_MODE=live` + clés live + nouveau webhook live

### 4. Frontend

Le `frontend/dist/` est compilé et commité (single dyno Python, pas de
buildpack Node). Pour recompiler après modification :

```bash
cd frontend && npm install && npm run build
```

### 5. Déploiement

```bash
git checkout -b v9-monetization
git add -A && git commit -m "v9: monétisation (SSO Google + crédits PayPal + admin)"
git push heroku v9-monetization:main
heroku config:set GOOGLE_CLIENT_ID=... GOOGLE_CLIENT_SECRET=... JWT_SECRET=... \
  ADMIN_EMAILS=... APP_BASE_URL=... PAYPAL_CLIENT_ID=... PAYPAL_CLIENT_SECRET=... \
  PAYPAL_MODE=sandbox PAYPAL_WEBHOOK_ID=...
```

## Barème par défaut (modifiable dans l'onglet admin « Tarification »)

| Pack | Prix | Crédits |
|------|------|---------|
| Découverte | 5 CAD | 50 |
| Standard | 15 CAD | 200 |
| Pro | 40 CAD | 650 |

Coût par requête : 10 crédits (standard), 15 crédits (vision).
Ces valeurs vivent en base (`app_settings`) — modifiables sans redéploiement.

## Tests de validation

1. Login Google sandbox → utilisateur créé avec 0 crédit ✓
2. Requête council à 0 crédit → HTTP 402 + modal d'achat ✓
3. Achat pack Découverte (sandbox) → +50 crédits + ligne transaction ✓
4. Rejeu du webhook PayPal → pas de double-crédit (index unique) ✓
5. Requête council → −10 crédits, conversation en Postgres ✓
6. Échec pipeline (clé OpenRouter invalide) → remboursement automatique ✓
7. Modèle invalide ajouté par l'admin → rejeté à la validation OpenRouter ✓
8. Non-admin sur `GET /api/admin/users` → 401/403 ✓
9. Compte désactivé → login refusé (redirect `account_disabled`) ✓
10. Restart du dyno → utilisateurs, crédits, conversations intacts (tout en Postgres) ✓

## Notes de migration v8 → v9

- Les conversations pré-v9 (sans `user_id`) ne sont visibles que par les admins.
- Les documents restent stockés sur le système de fichiers du dyno
  (éphémère sur Heroku, comme en v8) mais sont désormais rattachés à leur
  uploadeur — aucun utilisateur ne voit les documents d'un autre.
- `psycopg2-binary` a été ajouté aux requirements (manquant en v8 alors que
  `storage.py` en dépend dès que `DATABASE_URL` est présent).
