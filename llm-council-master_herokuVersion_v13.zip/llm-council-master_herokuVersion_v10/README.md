# LLM Council

![llmcouncil](header.jpg)

The idea of this repo is that instead of asking a question to your favorite LLM provider (e.g. OpenAI GPT 5.1, Google Gemini 3.0 Pro, Anthropic Claude Sonnet 4.5, xAI Grok 4, eg.c), you can group them into your "LLM Council". This repo is a simple, local web app that essentially looks like ChatGPT except it uses OpenRouter to send your query to multiple LLMs, it then asks them to review and rank each other's work, and finally a Chairman LLM produces the final response.

**Version 2.1.0** now supports **LM Studio integration** for running local models alongside cloud-based ones!

In a bit more detail, here is what happens when you submit a query:

1. **Stage 1: First opinions**. The user query is given to all LLMs individually, and the responses are collected. The individual responses are shown in a "tab view", so that the user can inspect them all one by one.
2. **Stage 2: Review**. Each individual LLM is given the responses of the other LLMs. Under the hood, the LLM identities are anonymized so that the LLM can't play favorites when judging their outputs. The LLM is asked to rank them in accuracy and insight.
3. **Stage 3: Final response**. The designated Chairman of the LLM Council takes all of the model's responses and compiles them into a single final answer that is presented to the user.

## Vibe Code Alert

This project was 99% vibe coded as a fun Saturday hack because I wanted to explore and evaluate a number of LLMs side by side in the process of [reading books together with LLMs](https://x.com/karpathy/status/1990577951671509438). It's nice and useful to see multiple responses side by side, and also the cross-opinions of all LLMs on each other's outputs. I'm not going to support it in any way, it's provided here as is for other people's inspiration and I don't intend to improve it. Code is ephemeral now and libraries are over, ask your LLM to change it in whatever way you like.

## Setup

### 1. Install Dependencies

The project uses [uv](https://docs.astral.sh/uv/) for project management.

**Backend:**
```bash
uv sync
```

**Frontend:**
```bash
cd frontend
npm install
cd ..
```

### 2. Configure API Key

Create a `.env` file in the project root:

```bash
OPENROUTER_API_KEY=sk-or-v1-...
```

Get your API key at [openrouter.ai](https://openrouter.ai/). Make sure to purchase the credits you need, or sign up for automatic top up.

### 3. Configure Models (Optional)

Edit `backend/config.py` to customize the council:

```python
COUNCIL_MODELS = [
    "openai/gpt-5.1",
    "google/gemini-3-pro-preview",
    "anthropic/claude-sonnet-4.5",
    "x-ai/grok-4",
]

CHAIRMAN_MODEL = "google/gemini-3-pro-preview"
```

## Running the Application

**Option 1: Use the start script**
```bash
./start.sh
```

**Option 2: Run manually**

Terminal 1 (Backend):
```bash
uv run python -m backend.main
```

Terminal 2 (Frontend):
```bash
cd frontend
npm run dev
```

Then open http://localhost:5173 in your browser.

## Tech Stack

- **Backend:** FastAPI (Python 3.10+), async httpx, OpenRouter API
- **Frontend:** React + Vite, react-markdown for rendering
- **Storage:** JSON files in `data/conversations/`
- **Package Management:** uv for Python, npm for JavaScript
- **Local Models:** LM Studio integration (OpenAI-compatible API)

## LM Studio Integration (New in v2.1.0)

You can now use local models through LM Studio instead of or alongside OpenRouter:

1. **Download LM Studio** from [lmstudio.ai](https://lmstudio.ai)
2. **Load a model** and start the local server (usually http://localhost:1234/v1)
3. **Enable CORS** in LM Studio settings
4. **Configure in LLM Council**: Go to Settings > LM Studio and enter the URL for each model you want to run locally
5. **Test connection** to verify it's working

Benefits of local models:
- **Privacy**: Queries stay on your machine
- **Cost**: No API fees for local inference
- **Offline**: Works without internet connection
- **Mixed mode**: Use local for some models, cloud for others

---

## v9 — Monétisation (SSO Google + Crédits PayPal + Admin)

### Configuration Google OAuth 2.0
1. Aller sur https://console.cloud.google.com → **APIs & Services → OAuth consent screen** (type External).
2. **Credentials → Create credentials → OAuth client ID → Web application**.
3. **Authorized redirect URIs** — ajouter :
   - `https://<votre-app>.herokuapp.com/api/auth/callback` (production)
   - `https://<votre-preview>.preview.emergentagent.com/api/auth/callback` (aperçu)
4. Copier le Client ID / Secret dans les variables d'env `GOOGLE_CLIENT_ID` / `GOOGLE_CLIENT_SECRET`.
5. Définir `ADMIN_EMAILS` (séparés par virgules) — ces emails deviennent admin à la connexion.

### Variables d'environnement (voir backend/.env.example)
`DATABASE_URL`, `DB_SSLMODE`, `JWT_SECRET`, `ADMIN_EMAILS`, `GOOGLE_CLIENT_ID`,
`GOOGLE_CLIENT_SECRET`, `COOKIE_SECURE`, `DEV_AUTH`, `PAYPAL_MODE`, `PAYPAL_CLIENT_ID`,
`PAYPAL_CLIENT_SECRET`, `PAYPAL_WEBHOOK_ID`, `OPENROUTER_API_KEY`.

- **DEV_AUTH** : mettre `1` uniquement en aperçu pour tester sans Google (endpoint
  `/api/auth/dev-login`). **Doit être `0` en production.**
- **PAYPAL_MODE** : `sandbox` par défaut ; passer `live` + nouvelles clés pour la production.

### Base de données
Migrations Alembic : `alembic upgrade head` (exécuté automatiquement en phase `release`
du Procfile sur Heroku). Tables : users, credit_transactions, app_settings, conversations.

### Modèle de crédits
Chaque requête au council débite des crédits (barème configurable dans Admin → Tarification).
Achat de packs via PayPal (transaction unique). Débit atomique + remboursement automatique
si le pipeline échoue.
