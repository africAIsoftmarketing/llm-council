import { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import Sidebar from './components/Sidebar';
import ChatInterface from './components/ChatInterface';
import Settings from './components/Settings';
import AdvancedPanel, { getAdvancedSettings } from './components/AdvancedPanel';
import AppHeader from './components/AppHeader';
import { useAuth } from './auth/AuthContext';
import { api } from './api';
import './App.css';
import './components/AppHeader.css';

function App() {
  const { refresh } = useAuth();
  const navigate = useNavigate();
  const [creditsModal, setCreditsModal] = useState(null);
  const [conversations, setConversations] = useState([]);
  const [currentConversationId, setCurrentConversationId] = useState(null);
  const [currentConversation, setCurrentConversation] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [currentView, setCurrentView] = useState('chat'); // 'chat' or 'settings'
  const [isConfigured, setIsConfigured] = useState(false);
  const [documents, setDocuments] = useState([]);
  const [toast, setToast] = useState(null);
  const [showAdvancedPanel, setShowAdvancedPanel] = useState(false);
  const [advancedSettings, setAdvancedSettings] = useState(() => getAdvancedSettings());
  const [councilModels, setCouncilModels] = useState([]);
  const [chairmanModel, setChairmanModel] = useState('');

  const checkConfiguration = useCallback(async () => {
    // The OpenRouter key is a deployment/admin concern; the end-user gate is now
    // the credit balance. Keep the chat UI available so credits/402 flow works.
    try {
      await api.healthCheck();
    } catch (error) {
      console.error('Failed to check configuration:', error);
    }
    setIsConfigured(true);
  }, []);

  const loadDocuments = useCallback(async () => {
    try {
      const result = await api.getDocuments();
      setDocuments(result.documents || []);
    } catch (error) {
      console.error('Failed to load documents:', error);
    }
  }, []);

  const loadCouncilConfig = useCallback(async () => {
    try {
      const config = await api.getConfig();
      setCouncilModels(config.council_models || []);
      setChairmanModel(config.chairman_model || '');
    } catch (error) {
      console.error('Failed to load council config:', error);
    }
  }, []);

  const loadConversations = useCallback(async () => {
    try {
      const convs = await api.listConversations();
      setConversations(convs);
    } catch (error) {
      console.error('Failed to load conversations:', error);
    }
  }, []);

  const loadConversation = useCallback(async (id) => {
    try {
      const conv = await api.getConversation(id);
      setCurrentConversation(conv);
    } catch (error) {
      console.error('Failed to load conversation:', error);
    }
  }, []);

  const showToast = useCallback((message, type = 'info') => {
    setToast({ message, type });
    setTimeout(() => setToast(null), 4000);
  }, []);

  // Check configuration status on mount
  useEffect(() => {
    // eslint-disable-next-line react-hooks/set-state-in-effect
    checkConfiguration();
     
    loadDocuments();
    loadCouncilConfig();
  }, [checkConfiguration, loadDocuments, loadCouncilConfig]);

  // Load conversations on mount
  useEffect(() => {
    // eslint-disable-next-line react-hooks/set-state-in-effect
    loadConversations();
  }, [loadConversations]);

  // Load conversation details when selected
  useEffect(() => {
    if (currentConversationId) {
      // eslint-disable-next-line react-hooks/set-state-in-effect
      loadConversation(currentConversationId);
    }
  }, [currentConversationId, loadConversation]);

  const handleNewConversation = async () => {
    try {
      const newConv = await api.createConversation();
      setConversations([
        { id: newConv.id, created_at: newConv.created_at, title: newConv.title, message_count: 0 },
        ...conversations,
      ]);
      setCurrentConversationId(newConv.id);
      setCurrentView('chat');
    } catch (error) {
      console.error('Failed to create conversation:', error);
      showToast('Failed to create conversation', 'error');
    }
  };

  const handleSelectConversation = (id) => {
    setCurrentConversationId(id);
    setCurrentView('chat');
  };

  const handleDeleteConversation = async (id) => {
    try {
      await api.deleteConversation(id);
      setConversations(conversations.filter(c => c.id !== id));
      if (currentConversationId === id) {
        setCurrentConversationId(null);
        setCurrentConversation(null);
      }
      showToast('Conversation deleted', 'success');
    } catch (error) {
      console.error('Failed to delete conversation:', error);
      showToast('Failed to delete conversation', 'error');
    }
  };

  const handleSendMessage = async (content, includeDocuments = true) => {
    if (!currentConversationId) return;

    setIsLoading(true);
    try {
      // Optimistically add user message to UI
      const userMessage = { role: 'user', content };
      setCurrentConversation((prev) => ({
        ...prev,
        messages: [...prev.messages, userMessage],
      }));

      // Create a partial assistant message that will be updated progressively
      const assistantMessage = {
        role: 'assistant',
        stage1: null,
        stage2: null,
        stage3: null,
        metadata: null,
        loading: {
          stage1: false,
          stage2: false,
          stage3: false,
        },
      };

      // Add the partial assistant message
      setCurrentConversation((prev) => ({
        ...prev,
        messages: [...prev.messages, assistantMessage],
      }));

      // Send message with streaming (include advanced settings)
      await api.sendMessageStream(currentConversationId, content, (eventType, event) => {
        switch (eventType) {
          case 'stage1_start':
            setCurrentConversation((prev) => {
              const messages = [...prev.messages];
              const lastMsg = messages[messages.length - 1];
              lastMsg.loading.stage1 = true;
              return { ...prev, messages };
            });
            break;

          case 'stage1_complete':
            setCurrentConversation((prev) => {
              const messages = [...prev.messages];
              const lastMsg = messages[messages.length - 1];
              lastMsg.stage1 = event.data;
              lastMsg.loading.stage1 = false;
              return { ...prev, messages };
            });
            break;

          case 'stage2_start':
            setCurrentConversation((prev) => {
              const messages = [...prev.messages];
              const lastMsg = messages[messages.length - 1];
              lastMsg.loading.stage2 = true;
              return { ...prev, messages };
            });
            break;

          case 'stage2_complete':
            setCurrentConversation((prev) => {
              const messages = [...prev.messages];
              const lastMsg = messages[messages.length - 1];
              lastMsg.stage2 = event.data;
              lastMsg.metadata = event.metadata;
              lastMsg.loading.stage2 = false;
              return { ...prev, messages };
            });
            break;

          case 'stage3_start':
            setCurrentConversation((prev) => {
              const messages = [...prev.messages];
              const lastMsg = messages[messages.length - 1];
              lastMsg.loading.stage3 = true;
              return { ...prev, messages };
            });
            break;

          case 'stage3_complete':
            setCurrentConversation((prev) => {
              const messages = [...prev.messages];
              const lastMsg = messages[messages.length - 1];
              lastMsg.stage3 = event.data;
              lastMsg.loading.stage3 = false;
              return { ...prev, messages };
            });
            break;

          case 'title_complete':
            // Reload conversations to get updated title
            loadConversations();
            break;

          case 'complete':
            // Stream complete, reload conversations list + refresh credit balance
            loadConversations();
            refresh();
            setIsLoading(false);
            break;

          case 'error':
            console.error('Stream error:', event.message);
            showToast(event.message || 'An error occurred', 'error');
            if (event.refunded) refresh();
            setIsLoading(false);
            break;

          default:
            console.log('Unknown event type:', eventType);
        }
      }, includeDocuments, advancedSettings);
    } catch (error) {
      console.error('Failed to send message:', error);
      // Remove optimistic messages on error
      setCurrentConversation((prev) => ({
        ...prev,
        messages: prev.messages.slice(0, -2),
      }));
      setIsLoading(false);
      if (error.status === 402) {
        const d = error.detail || {};
        setCreditsModal({ required: d.required, balance: d.balance });
      } else {
        showToast(error.message || 'Failed to send message', 'error');
      }
    }
  };

  const handleConfigUpdate = () => {
    checkConfiguration();
    loadCouncilConfig();
  };

  const handleAdvancedSettingsChange = (newSettings) => {
    setAdvancedSettings(newSettings);
  };

  const handleDocumentUpload = async (file) => {
    try {
      const result = await api.uploadDocument(file);
      await loadDocuments();
      showToast(`Document "${file.name}" uploaded successfully`, 'success');
      return result;
    } catch (error) {
      showToast(error.message || 'Failed to upload document', 'error');
      throw error;
    }
  };

  const handleDocumentDelete = async (docId) => {
    try {
      await api.deleteDocument(docId);
      await loadDocuments();
      showToast('Document deleted', 'success');
    } catch (error) {
      showToast('Failed to delete document', 'error');
    }
  };

  const handleDocumentToggle = async (docId, isActive) => {
    try {
      await api.toggleDocument(docId, isActive);
      await loadDocuments();
    } catch (error) {
      showToast('Failed to toggle document', 'error');
    }
  };

  return (
    <div className="app-shell">
      <AppHeader />
      <div className="app">
      <Sidebar
        conversations={conversations}
        currentConversationId={currentConversationId}
        onSelectConversation={handleSelectConversation}
        onNewConversation={handleNewConversation}
        onDeleteConversation={handleDeleteConversation}
        currentView={currentView}
        onViewChange={setCurrentView}
        isConfigured={isConfigured}
        onOpenAdvanced={() => setShowAdvancedPanel(true)}
        advancedMode={advancedSettings.mode}
      />
      
      {currentView === 'chat' ? (
        <ChatInterface
          conversation={currentConversation}
          onSendMessage={handleSendMessage}
          isLoading={isLoading}
          isConfigured={isConfigured}
          onGoToSettings={() => setCurrentView('settings')}
          documents={documents}
          onDocumentUpload={handleDocumentUpload}
          onDocumentDelete={handleDocumentDelete}
          onDocumentToggle={handleDocumentToggle}
        />
      ) : (
        <Settings
          onConfigUpdate={handleConfigUpdate}
          showToast={showToast}
        />
      )}

      {/* Advanced Panel */}
      {showAdvancedPanel && (
        <AdvancedPanel
          onClose={() => setShowAdvancedPanel(false)}
          onSettingsChange={handleAdvancedSettingsChange}
          councilModels={councilModels}
          chairmanModel={chairmanModel}
          showToast={showToast}
        />
      )}

      {/* Toast Notifications */}
      {toast && (
        <div className={`toast toast-${toast.type}`} data-testid="toast-notification">
          {toast.message}
        </div>
      )}

      {/* Insufficient credits modal */}
      {creditsModal && (
        <div className="credits-modal-overlay" data-testid="insufficient-credits-modal">
          <div className="credits-modal">
            <h3>Crédits insuffisants</h3>
            <p>
              Cette requête nécessite <strong>{creditsModal.required}</strong> crédits, mais votre
              solde est de <strong>{creditsModal.balance}</strong>.
            </p>
            <div className="credits-modal-actions">
              <button className="cm-secondary" onClick={() => setCreditsModal(null)} data-testid="credits-modal-cancel">Annuler</button>
              <button className="cm-primary" onClick={() => navigate('/credits')} data-testid="credits-modal-buy">Acheter des crédits</button>
            </div>
          </div>
        </div>
      )}
      </div>
    </div>
  );
}

export default App;
